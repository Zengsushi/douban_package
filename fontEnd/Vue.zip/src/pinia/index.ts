import {defineStore} from "pinia"
import { type Movie, type User  } from "@/pojo/index"

import {  getUserInfos , getCategory } from "@/views/api/index"

export const useStore = defineStore("main", {
    state: () => ({
        id : "0" , 
        movie: {} as Movie ,
        user : {} as User , 
        categoryarr : [] , 
        type : "" , 
    }), 
    actions: {
        setId(id : any){
            this.id = id
        }, 
        setMovie( movie:Movie ){
            this.movie = movie
        } , 
        setUserInfo(user: User){
            this.user = user
        } , 
        async setUserInfos(){ 
            console.log(localStorage.getItem("id"));
            // const res =await getUserInfos(localStorage.getItem("id"))
            // localStorage.setItem("user" ,res.data.data)
        },
        setSearchStr(str : any){
            this.type = str
        }
    } ,

})