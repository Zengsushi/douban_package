import { createRouter, createWebHistory } from 'vue-router'


import Login from "@/views/User/Login.vue"
import Register from "@/views/User/Register.vue"
import Home from "@/views/Home.vue"


import MovieList from "@/views/Movie/MovieList.vue"
import Movies from "@/views/Movie/Movies.vue"
import Info from "@/views/Movie/MovieInto.vue"

import China from "@/views/vls/book/China.vue"

import Rose from "@/views/vls/book/Rose.vue"
import Book from "@/views/vls/Book.vue"
import Movie from "@/views/vls/Movie.vue"
import Bar2 from "@/views/vls/book/Bar2.vue"
import WordClound from '@/views/vls/module/WordClound.vue'
import BookWordCloud from "@/views/vls/book/bookWordCloud.vue"

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path : '/' ,
      name : "登录" ,
      component: Login
    } ,
    {
      path : "/register" ,
      name : "注册" ,
      component : Register
    }, {
      path : "/home" ,
      name : "首页" ,
      component : Home, 
      children: [
        // {
        //   path: "movieList", 
        //   name : "电影列表" ,
        //   component : MovieList
        // } , 
        {
          path: "wordCloud", 
          name : "词云图" ,
          component : WordClound 
        } , 
      ]
    },{
      path: "/movies", 
      name : "电影详情" ,
      component : Movies,
    }, 
    {
      path: "/info",
      name: "详细信息" ,
      component:  Info 
    }, {
      path : "/BookVls" , 
      name : "数据分析大屏" ,
      component: Book
    } , {
      path : "/china" ,
      name : "中国地图" ,
      component : China
    } , {
      path : "/MovieVls" , 
      name : "电影分析大屏" ,
      component: Movie
    } , {
      path : "/bookWordClond" ,
      name : "书籍词云图" ,
      component : BookWordCloud
    } , {
      path : "/rose" ,
      name : "书籍类型" ,
      component : Rose
    } , {
      path : "/bar2" ,
      name : "书籍类型" ,
      component : Bar2
    } ,
  ],
})


export default router
