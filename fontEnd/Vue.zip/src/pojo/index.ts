import {ref} from "vue"
// 影片
export interface Movie {
    id? : String ,
    title? : String
    year? : String
    duration? : String
    director? : String
    author? : String
    actor? : String
    region? : String
    type? : String
    score? : number
    url? : String
    description? : String
    createTime? : String
    updateTime? : String
}

// 国家地区
export interface Region {
    id? : string , 
    name? : string 
}

// 类型
export interface Type {
    id? : string , 
    name? : string 
}

// 分页
export interface MvPage{
id? : string ,
mvId? : string ,
content? : string ,
userId? : string ,
reCount? : string , 
createTime ? : string
}

// 评论
export interface Comments{
    id? :string
    mvId? :string
    content? :string
    userId? :string 
    reCount? :number
    nickname? :string
    commentShow : boolean
    repliesShow : boolean 
    inputShow : boolean 
}

// 回复
export interface Replies{
    id? : string
    content? : string
    userId? : string
    nickname? : string 
    commentId? : string
    createTime? : string
}

// 用户
export interface User{
    id ? : string
    name ? : string
    pass ? : string
    nickName? : string
    email ? : string
    gender? : string
    birth? : string
    createTime? : string
    updateTime? : string
}
export interface Users{
    id ? : string 
    name ? : string 
    pass ? : string 
    nickName? : string 
    email ? : string 
    gender? : string 
    birth? : string 
    createTime? : string 
    updateTime? : string 
}

export interface Props {
    name?: string;
    number?: string; 
    duration?: number;
    digitHeight?: number;
    delayStep?: number;
  }

export interface Digit {
    value: string;
    position: number;
  }



  export interface CountryData {
  name: string
  value: number
}

export interface ChartOption {
  tooltip: {
    trigger: string
    formatter: (params: any) => string
  }
  visualMap: {
    min: number
    max: number
    text: string[]
    realtime: boolean
    calculable: boolean
    inRange: {
      color: string[]
    }
  }
  series: Array<{
    name: string
    type: string
    mapType: string
    roam: boolean
    nameMap: Record<string, string>
    itemStyle: {
      areaColor: string
      emphasis: {
        label: {
          show: boolean
        }
      }
    }
    data: CountryData[]
  }>
}

export interface WorldMapProps {
  data?: CountryData[]
  title?: string
  height?: string
  width?: string
}

export interface Data{
  name? : string , 
  value? : number
} 

