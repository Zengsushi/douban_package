import instance  from "@/utils/result";
import { type Movie } from "@/pojo";

// 管理员登录
export const AdminLogin = (data:any) => {    
    return  instance.post("/user/adminLogin", data )
}
// 用户登录
export const UserLogin = (data:any) => {
    return instance.post("/user/userLogin" , data)
}
//用户注册
export const UesrRegister = (data:any) => {
    return instance.post("/user/userRegister" , data)
}
// 用户退出
export const updateUserInfo = ( user : any ) => {
    return instance.post("/user/updateUserInfo",  user );
};


// 电影列表
export const MovieList = (page: any) => {
    console.log(page);
    return instance.post("movie/movieList" , page)
}
// 电影删除
export const MovieDetail = (data:Movie) => {
    return instance.post("/movie/deleteMovie" , data)
}
// 搜索电影
export const searchMovieInfo = (data:Movie) => {
    return instance.post("/movie/searchMovie" , data)
}
// 国家 地区
export const getRegionList = () => {
    return instance.get("/movie/regionList")
}
// 类型
export const getTypeList = () => {
    return instance.get("/movie/typeList")
}
// 电影数量
export const getMovieCount = () => {
    return instance.get("/movie/movieCount")
}
// 修改电影信息
export const updateMovieInfo = (movie:Movie) => {
    return instance.post("/movie/updateMovie" , movie)
}
// 点击电影埋点
export const ClickMovie = (data: Movie) => {
    return instance.post("/movie/clickMovie" , data)
}
// 点击次数前15
export const GetClickTop10 = () => {
    return instance.get("/movie/clickTop10")
}
// 获取电影详细信息
export const GetMvInfo = (data : any) => {
    return instance.post("/movie/info" , data)
}
// 获取用户信息
export const GetUserInfo = (id : any) => {
    return instance.post("/user/userInfo" , {"id" : id})
}
// 添加评论
export const AddComments = (data : any) => {
    return instance.post("/comment/addComments", data)
}
// 获取评论
export const GetComments = (data : any) => {
    return instance.post("/comment/getComments", data)
}
// 删除评论
export const DeleteComments = (data : any) => {
    return instance.post("/comment/deleteComments", data)
}
// 添加评论回复
export const AddReplies = (data : any) => {
    return instance.post("/comment/addReplies" , data)
}
// 获取评论回复列表
export const GetReplies = (data : any) => { 
    return instance.post("/comment/getReplies" , data)
}
// 用户用户信息
export const  getUserInfos = (data : string) => {
    return instance.post("/user/getUserInfo" , {id : data} )
}
// 用户登出
export const UserLogout = (data : any) => {
    return instance.post("/user/userLogOut" , {id : data} )
}

// 饼图时长数据
export const getCategory = () => {
    return instance.get("/movie/getCategory")
}

// 饼图 评分数据
export const getScore = () =>{
    return instance.get("/movie/getScoreCnt")
}

// 柱状图 评分数据
export const getScoreCnt = () => {
    return instance.get("/movie/getScore")
}

//  词云图 类型数据
export const GetTypeCnt = () => {
    return instance.get("movie/getTypeCnt")
}

// 旭日图 数据
export const GetRegionCnt = () => {
    return instance.get("/movie/getRegionCnt") 
}

// 翻牌器 数据
export const getRegionNumberCnt = () => {
    return instance.get("/movie/getNumberCnt")
}

// 折线图 数据
export const getYearCnt = () => {
    return instance.get("/movie/getYearCnt")
}

// 通过电影名称获取电影id
export const GetFindByTitle = (data:any) => {
    return instance.post("/movie/getFinBbyTitle",data)
}

// 漏斗图 数据( 根据评分人数 并且平均评分大于8.0)
export const getMvScoreCntTop25 = () => {
    return instance.get("/movie/getTop250")
}


// 书籍中国地图
export const getBookData = () => {
    return instance.get("/book/chinaMap")
}

// 书籍词云图
export const getBookPress = () => {
    return instance.get("/book/bookPress")
}

// 书籍出版国家统计( 翻牌器)
export const getRegionCnt = () => {
    return instance.get("/book/bookRegion")
}

// 书籍类型 (玫瑰图)
export const getBookTypeCnt = () => {
    return instance.get("/book/bookType")
}

// 书籍年份 (折线图)
export const getBookYearCnt = () => {
    return instance.get("/book/bookYear")
}


// 书籍页数
export const getBookPageCnt = () => {
    return instance.get("/book/constbookPage")
}

// 数据价格 
export const  getBookPrice = () => {
    return instance.get("/book/bookPrice")
}