

<template></template>


<!-- <template>
  <div class="container">
  
    <div class="search-container">
      <el-input 
        v-model="searchStr" 
        placeholder="请输入电影名称" 
        clearable 
        class="search-input"
        @keyup.enter="searchMovie"
      >
        <template #prefix>
          <el-icon><Search /></el-icon>
        </template>
      </el-input>
      
      <el-button 
        @click="searchMovie" 
        type="primary" 
        class="search-button"
      >
        <el-icon><Search /></el-icon>
        <span>搜索</span>
      </el-button>

      <el-select 
        v-model="movieType" 
        placeholder="选择地区" 
        class="search-select"
        clearable
      >
        <el-option 
          v-for="value in region" 
          :key="value.id" 
          :label="value.name" 
          :value="value.name" 
        />
      </el-select>

      <el-select 
        v-model="movieGenre" 
        placeholder="选择类型" 
        class="search-select"
        clearable
      >
        <el-option 
          v-for="value in type" 
          :key="value.id" 
          :label="value.name" 
          :value="value.name" 
        />
      </el-select>
      
      <el-button 
        @click="resetSearch" 
        class="reset-button"
      >
        <el-icon><Refresh /></el-icon>
        <span>重置</span>
      </el-button>
    </div>

  
    <el-card shadow="never" class="table-card">
      <el-table 
        :data="arr" 
        v-loading="loading"
        stripe
        style="width: 100%"
        :header-cell-style="{ background: '#f5f7fa', color: '#606266' }"
      >
        <el-table-column prop="id" label="ID" width="80" fixed />
        <el-table-column prop="title" label="名称" width="180" show-overflow-tooltip />
        <el-table-column prop="year" label="上映年份" width="100" align="center" />
        <el-table-column prop="region" label="出品国家" width="120" show-overflow-tooltip />
        <el-table-column prop="type" label="类型" width="120" show-overflow-tooltip />
        <el-table-column prop="director" label="导演" width="150" show-overflow-tooltip />
        <el-table-column prop="actor" label="主要演员" width="200" show-overflow-tooltip />
        <el-table-column prop="count" label="评分人数" width="100" align="center" sortable />
        <el-table-column prop="score" label="评分" width="100" align="center" sortable />
        <el-table-column prop=score label="星级" width="100" align="center">
          <template #default="{ row }">
            <el-rate 
              v-model="row.star" 
              disabled 
              show-score 
              :max="5" 
              :colors="['#99A9BF', '#F7BA2A', '#FF9900']" 
            />
          </template>
        </el-table-column>
        <el-table-column label="海报" width="150" align="center">
          <template #default="{ row }">
            <el-image 
              v-if="row.url" 
              :src="row.url" 
              :preview-src-list="[row.url]" 
              fit="cover" 
              class="movie-poster"
              :hide-on-click-modal="true"
            >
              <template #error>
                <div class="image-error">
                  <el-icon><Picture /></el-icon>
                  <span>加载失败</span>
                </div>
              </template>
            </el-image>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="120" fixed="right" align="center">
          <template #default="{ row }">
            <el-button 
              link 
              type="primary" 
              size="small" 
              @click="openDrawer(row)"
            >
              <el-icon><Edit /></el-icon>
              <span>编辑</span>
            </el-button>
            <el-popconfirm 
              title="确认删除该电影?" 
              @confirm="handleDelete(row)"
              confirm-button-text="确认"
              cancel-button-text="取消"
              icon-color="#F56C6C"
            >
              <template #reference>
                <el-button link type="danger" size="small">
                  <el-icon><Delete /></el-icon>
                  <span>删除</span>
                </el-button>
              </template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <div class="pagination-container">
      <el-pagination
        v-model:current-page="mvPage.page"
        v-model:page-size="mvPage.size"
        :total="totalItems"
        :page-sizes="[10, 20, 50, 100]"
        layout="total, sizes, prev, pager, next, jumper"
        background
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </div>

    <el-drawer 
      v-model="drawer" 
      :size="600"
      :close-on-click-modal="false"
    >
      <template #header>
        <h3 class="drawer-title">
          <el-icon><Edit /></el-icon>
          <span>{{ tempMovie?.id ? '编辑电影' : '新增电影' }}</span>
        </h3>
      </template>
      
      <el-form 
        :model="tempMovie" 
        label-width="100px" 
        label-position="left"
        :rules="rules"
        ref="formRef"
      >
        <el-form-item label="电影名称" prop="title">
          <el-input v-model="tempMovie.title" placeholder="请输入电影名称" />
        </el-form-item>
        
        <el-form-item label="上映年份" prop="year">
          <el-date-picker
            v-model="tempMovie.year"
            type="year"
            placeholder="选择年份"
            value-format="YYYY"
            style="width: 100%"
          />
        </el-form-item>
        
        <el-form-item label="出品国家" prop="region">
          <el-select v-model="tempMovie.region" placeholder="请选择国家" style="width: 100%">
            <el-option 
              v-for="item in region" 
              :key="item.id" 
              :label="item.name" 
              :value="item.name" 
            />
          </el-select>
        </el-form-item>
        
        <el-form-item label="电影类型" prop="type">
          <el-select v-model="tempMovie.type" placeholder="请选择类型" style="width: 100%">
            <el-option 
              v-for="item in type" 
              :key="item.id" 
              :label="item.name" 
              :value="item.name" 
            />
          </el-select>
        </el-form-item>
        
        <el-form-item label="导演" prop="director">
          <el-input v-model="tempMovie.director" placeholder="请输入导演姓名" />
        </el-form-item>
        
        <el-form-item label="主要演员" prop="actors">
          <el-input 
            v-model="tempMovie.actors" 
            placeholder="请输入主要演员，用逗号分隔" 
            type="textarea"
            :rows="2"
          />
        </el-form-item>
        
        <el-form-item label="评分人数" prop="count">
          <el-input-number 
            v-model="tempMovie.count" 
            :min="0" 
            controls-position="right"
            style="width: 100%"
          />
        </el-form-item>
        
        <el-form-item label="评分" prop="score">
          <el-input-number 
            v-model="tempMovie.score" 
            :min="0" 
            :max="10" 
            :step="0.1"
            controls-position="right"
            style="width: 100%"
          />
        </el-form-item>
        
        <el-form-item label="星级" prop="star">
          <el-rate 
            v-model="tempMovie.star" 
            :max="5" 
            :colors="['#99A9BF', '#F7BA2A', '#FF9900']" 
            show-text
            style="padding-top: 8px"
          />
        </el-form-item>
        
        <el-form-item label="海报地址" prop="url">
          <el-input v-model="tempMovie.url" placeholder="请输入海报URL地址" />
          <div class="preview-container" v-if="tempMovie.url">
            <span class="preview-label">预览:</span>
            <el-image 
              :src="tempMovie.url" 
              fit="contain" 
              style="height: 100px"
              :preview-src-list="[tempMovie.url]"
            >
              <template #error>
                <div class="image-error">
                  <el-icon><Picture /></el-icon>
                  <span>图片加载失败</span>
                </div>
              </template>
            </el-image>
          </div>
        </el-form-item>
      </el-form>
      
      <template #footer>
        <div class="drawer-footer">
          <el-button @click="drawer = false">取消</el-button>
          <el-button type="primary" @click="updateMovie" :loading="submitting">
            保存
          </el-button>
        </div>
      </template>
    </el-drawer>
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted, reactive } from 'vue';
import { 
  Search, 
  Refresh, 
  Edit, 
  Delete, 
  Picture 
} from '@element-plus/icons-vue';
import { 
  searchMovieInfo, 
  MovieList, 
  MovieDetail,  
  getRegionList, 
  getTypeList, 
  getMovieCount, 
  updateMovieInfo
} from "../api/index";
import { 
  type Movie, 
  type Region, 
  type Type, 
  type MvPage 
} from "../../pojo/index";
import { ElMessage, type FormInstance, type FormRules } from 'element-plus';

const arr = ref<Movie[]>([]);
const region = ref<Region[]>([]);
const type = ref<Type[]>([]);
const loading = ref(false);
const submitting = ref(false);

const searchStr = ref("");
const movieType = ref<string | null>(null);
const movieGenre = ref<string | null>(null);

const drawer = ref(false);
const tempMovie = ref<Partial<Movie>>({
  title: '',
  year: '',
  region: '',
  type: '',
  director: '',
  actors: '',
  count: 0,
  score: 0,
  star: 0,
  url: ''
});

const totalItems = ref(0);
const mvPage = reactive<MvPage>({ 
  page: 1, 
  size: 10 
});

const formRef = ref<FormInstance>();
const rules = reactive<FormRules>({
  title: [{ required: true, message: '请输入电影名称', trigger: 'blur' }],
  year: [{ required: true, message: '请选择上映年份', trigger: 'change' }],
  region: [{ required: true, message: '请选择出品国家', trigger: 'change' }],
  type: [{ required: true, message: '请选择电影类型', trigger: 'change' }],
  score: [
    { required: true, message: '请输入评分', trigger: 'blur' },
    { type: 'number', min: 0, max: 10, message: '评分必须在0-10之间', trigger: 'blur' }
  ]
});

// 获取电影数据
const getMovie = async () => {
  try {
    loading.value = true;
    const res = await MovieList(mvPage);
    if(res.data.code === 0) {
      arr.value = res.data.data;
    } else {
      ElMessage.error(res.data.message || '获取电影列表失败');
    }
  } catch (error) {
    ElMessage.error('获取电影列表失败');
    console.error('获取电影列表失败:', error);
  } finally {
    loading.value = false;
  }
};

// 更新电影信息
const updateMovie = async () => {
  try {
    submitting.value = true;
    await formRef.value?.validate();
    
    const res = await updateMovieInfo(tempMovie.value);
    if(res.data.code === 0) {
      ElMessage.success('操作成功');
      drawer.value = false;
      getMovie();
      getMvTotal();
    } else {
      ElMessage.error(res.data.message || '操作失败');
    }
  } catch (error) {
    console.error('操作失败:', error);
  } finally {
    submitting.value = false;
  }
};

// 分页处理
const handleSizeChange = (newSize: number) => {    
  mvPage.size = newSize;
  mvPage.page = 1;
  getMovie();
};

const handleCurrentChange = (newPage: number) => {
  mvPage.page = newPage;
  getMovie();
};

// 搜索电影
const searchMovie = async() => {
  try {
    loading.value = true;
    const res = await searchMovieInfo({ 
      title: searchStr.value,
      region: movieType.value, 
      type: movieGenre.value 
    });
    
    if(res.data.code === 0) {
      arr.value = res.data.data;
      totalItems.value = arr.value.length;
      mvPage.page = 1;
    } else {
      ElMessage.error(res.data.message || '搜索失败');
    }
  } catch (error) {
    ElMessage.error('搜索失败');
    console.error('搜索失败:', error);
  } finally {
    loading.value = false;
  }
};

// 重置搜索
const resetSearch = () => {
  searchStr.value = "";
  movieType.value = null;
  movieGenre.value = null;
  getMovie();
  getMvTotal();
};

// 删除电影
const handleDelete = async (row: Movie) => {
  try {
    loading.value = true;
    const res = await MovieDetail(row);
    if(res.data.code === 0) {
      arr.value = arr.value.filter(movie => movie.id !== row.id);
      totalItems.value -= 1;
      ElMessage.success('删除成功');
    } else {
      ElMessage.error(res.data.message || '删除失败');
    }
  } catch (error) {
    ElMessage.error('删除失败');
    console.error('删除电影失败:', error);
  } finally {
    loading.value = false;
  }
};

// 获取电影总数
const getMvTotal = async() => {
  const res = await getMovieCount();
  if(res.data.code === 0) {
    totalItems.value = res.data.data;
  } else {
    ElMessage.error(res.data.message || '获取总数失败');
  }
};

// 打开编辑抽屉
const openDrawer = (row?: Movie) => {
  if (row) {
    tempMovie.value = { ...row };
  } else {
    tempMovie.value = {
      title: '',
      year: '',
      region: '',
      type: '',
      director: '',
      actors: '',
      count: 0,
      score: 0,
      star: 0,
      url: ''
    };
  }
  drawer.value = true;
};

// 获取地区和类型数据
const getList = async (fun: () => Promise<any>, data: any) => {
  try {
    const res = await fun();
    if (res.data.code === 0) {
      data.value = res.data.data;
    } else {
      ElMessage.error(res.data.message || '获取数据失败');
    }
  } catch (error) {
    ElMessage.error('获取数据失败');
    console.error('获取数据失败:', error);
  }
};

// 初始化
onMounted(() => {
  getMovie();
  getMvTotal();
  getList(getRegionList, region);
  getList(getTypeList, type);
});
</script>

<style scoped>
.container {
  padding: 20px;
  background-color: #f5f7fa;
  min-height: calc(100vh - 40px);
}

/* 搜索区域 */
.search-container {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 12px;
  margin-bottom: 20px;
  padding: 16px;
  background-color: #ffffff;
  border-radius: 8px;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.08);
}

.search-input {
  width: 280px;
}

.search-button {
  width: 100px;
}

.search-select {
  width: 180px;
}

.reset-button {
  margin-left: auto;
}

/* 表格卡片 */
.table-card {
  margin-bottom: 20px;
  border-radius: 8px;
  border: none;
}

/* 电影海报 */
.movie-poster {
  width: 100px;
  height: 140px;
  border-radius: 4px;
  object-fit: cover;
  transition: transform 0.3s ease;
  cursor: pointer;
}

.movie-poster:hover {
  transform: scale(1.05);
}

.image-error {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  color: #c0c4cc;
  font-size: 12px;
}

/* 分页 */
.pagination-container {
  display: flex;
  justify-content: center;
  padding: 16px;
  background-color: #ffffff;
  border-radius: 8px;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.08);
}

/* 抽屉样式 */
.drawer-title {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0;
  color: #303133;
}

.drawer-footer {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  padding-top: 16px;
  border-top: 1px solid #e8e8e8;
}

.preview-container {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-top: 8px;
}

.preview-label {
  color: #909399;
  font-size: 14px;
}

/* 响应式设计 */
@media (max-width: 992px) {
  .search-container {
    flex-direction: column;
    align-items: stretch;
  }
  
  .search-input,
  .search-button,
  .search-select {
    width: 100%;
  }
  
  .reset-button {
    margin-left: 0;
  }
}

@media (max-width: 768px) {
  .container {
    padding: 12px;
  }
  
  .movie-poster {
    width: 80px;
    height: 120px;
  }
}
</style> -->