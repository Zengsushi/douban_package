<template>
  <div class="app-container">
    <!-- 电影 
    读书 -->
    <!-- 用户信息 -->
    <div class="app-header">
      <div class="user-profile">
        <el-dropdown trigger="click" @command="handleCommand">
          <div class="user-info">
            <el-avatar :size="32"  class="user-avatar">
              {{ user?.nickName?.charAt(0) }}
            </el-avatar>
            <span class="username">{{ user?.nickName }}</span>
            <el-icon class="el-icon--right"><arrow-down /></el-icon>
          </div>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item command="profile">
                <el-icon><User /></el-icon>
                <span>个人信息</span>
              </el-dropdown-item>
              <el-dropdown-item command="settings">
                <el-icon><Setting /></el-icon>
                <span>设置</span>
              </el-dropdown-item>
              <el-dropdown-item divided command="logout">
                <el-icon><SwitchButton /></el-icon>
                <span>退出登录</span>
              </el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>
    </div>

    <!-- 主要内容区域 -->
    <div class="main-content">
      <!-- 搜索区域 -->
      <div class="search-section">
        <div class="search-container">
          <div class="search-input-container">
            <el-input
              v-model="searchStr"
              placeholder="请输入电影名称"
              clearable
              class="search-input"
              @keyup.enter="searchMovie"
            >
              <template #prefix>
                <el-icon><Search /></el-icon>
              </template>
            </el-input>
            <el-button
              @click="searchMovie"
              type="primary"
              class="search-button"
              :icon="Search"
            >
              搜索
            </el-button>
          </div>

          <div class="filters-container">
            <el-form-item label="地区" class="filter-item">
              <el-select
                v-model="movieRegion"
                placeholder="选择地区"
                class="filter-select"
                clearable
              >
                <el-option
                  v-for="value in region"
                  :key="value.id"
                  :label="value.name"
                  :value="value.name"
                />
              </el-select>
            </el-form-item>

            <el-form-item label="类型" class="filter-item">
              <el-select
                v-model="movieType"
                placeholder="选择类型"
                class="filter-select"
                clearable
              >
                <el-option
                  v-for="value in type"
                  :key="value.id"
                  :label="value.name"
                  :value="value.name"
                />
              </el-select>
            </el-form-item>
          </div>
        </div>
      </div>

      <!-- 电影列表 -->
      <div class="movie-list-section">
        <div class="movie-list-container">
          <el-row :gutter="20" class="movie-list">
            <el-col
              :xs="24"
              :sm="12"
              :md="8"
              :lg="6"
              v-for="movie in arr"
              :key="movie.id"
            >
              <el-card
                class="movie-card"
                @click="onCardClick(movie)"
                shadow="hover"
              >
                <div class="movie-poster-container">
                  <el-image
                    :src="movie.url"
                    alt="电影海报"
                    class="movie-poster"
                    fit="cover"
                    :lazy="true"
                  >
                    <template #error>
                      <div class="poster-error">
                        <el-icon><Picture /></el-icon>
                        <span>海报加载失败</span>
                      </div>
                    </template>
                  </el-image>
                  <div class="movie-rating" v-if="movie.score">
                    <el-rate
                      v-model="movie.score"
                      disabled
                      allow-half
                      :max="5"
                      :show-score="true"
                      score-template="{value}"
                    />
                  </div>
                </div>

                <div class="movie-info">
                  <h3 class="movie-title">
                    {{ movie.title?.split(" ")[0] }}
                    <span class="movie-year">{{ movie.year }}</span>
                  </h3>
                  <div class="movie-meta">
                    <div class="meta-item">
                      <el-icon><User /></el-icon>
                      <span class="meta-text">{{ movie.director || "未知" }}</span>
                    </div>
                    <div class="meta-item">
                      <el-icon><Location /></el-icon>
                      <span class="meta-text">{{ movie.region || "未知" }}</span>
                    </div>
                  </div>
                </div>
              </el-card>
            </el-col>
          </el-row>
        </div>

        <!-- 加载更多提示 -->
        <div v-if="loading" class="loading-container">
          <el-icon class="loading-icon" :size="20"><Loading /></el-icon>
          <span>正在加载更多...</span>
        </div>
        <div v-else-if="arr.length >= total" class="no-more">
          没有更多内容了
        </div>
      </div>
    </div>

    <div class="floating-rank-list" :class="{ 'collapsed': isCollapsed }">
    <div class="rank-header" @click="toggleCollapse">
      <el-icon><Trophy /></el-icon>
      <h3 class="rank-title">电影排行榜</h3>
      <el-icon class="collapse-icon">
        <ArrowRight v-if="isCollapsed" />
        <ArrowLeft v-else />
      </el-icon>
    </div>
    
    <el-collapse-transition>
      <div v-show="!isCollapsed">
        <el-scrollbar height="400px">
          <div
            class="rank-item"
            v-for="(movie, index) in topMovie"
            :key="movie.id ? String(movie.id) : ''"
            @click="onCardClick(movie)"
          >
            <div
              class="rank-number"
              :class="{
                'top1': index === 0,
                'top2': index === 1,
                'top3': index === 2,
              }"
            >
              {{ index + 1 }}
            </div>
            <div class="rank-content">
              <div class="rank-movie-title">{{ movie.title }}</div>
              <div class="rank-meta">
                <el-rate
                  v-model="movie.score"
                  disabled
                  allow-half
                  :max="5"
                  :show-score="true"
                  score-template="{value}"
                  class="rank-rating"
                />
              </div>
            </div>
          </div>
        </el-scrollbar>
      </div>
    </el-collapse-transition>
  </div>

  </div>
</template>

<!-- <script lang="ts" setup>
 
import {  ArrowRight, ArrowLeft } from '@element-plus/icons-vue';
import {
  ref,
  onMounted,
  onUnmounted,
  watch,
} from "vue";
import {
  User,
  Setting,
  SwitchButton,
  ArrowDown,
  Search,
  Picture,
  Location,
  Trophy,
  Loading,
} from "@element-plus/icons-vue";
import { ElMessageBox } from "element-plus";
import {
  MovieList,
  getRegionList,
  getTypeList,
  ClickMovie,
  getMovieCount,
  GetClickTop10,
  searchMovieInfo,
  UserLogout,
} from "@/views/api/index";
import type { Movie, MvPage, Region, Type, Users } from "@/pojo/index";
import router from "@/router";
import { useStore } from "@/pinia/index";
import {GetUserInfo} from "@/views/api/index"
import { useRoute } from 'vue-router';
import { ElMessage} from "element-plus"

const store = useStore()
const arr = ref<Movie[]>([]);
const topMovie = ref<Movie[]>([]);
const list = ref<MvPage>({ size: 12, page: 1 });
const searchStr = ref("");
const loading = ref(false);
const region = ref<Region[]>([]);
const type = ref<Type[]>([]);
const total = ref(0);
const movieRegion= ref("");
const movieType = ref("");
const user = ref<Users>();
const route = useRoute();

// 获取电影数据
const getMovie = async () => {
  loading.value = true;
  try {
    const res = await MovieList(list.value);
    const res2 = await getMovieCount();
    if (res.data.code === 0) {
      arr.value.push(...res.data.data);
    }
    if (res2.data.code === 0) {
      total.value = res2.data.data;
    }
  } catch (error) {
    console.error("获取电影列表失败:", error);
  } finally {
    loading.value = false;
  }
};
//获取用户信息
const getUserInfo = async () => {
      const res = await GetUserInfo( localStorage.getItem("uId"))
      if( res.data.code === 0 ){
        user.value = res.data.data
      }else{
        ElMessage.warning(res.data.message)
      }
}

// 获取地区和类型列表
const getList = async (fun: () => Promise<any>, data: any) => {
  const res = await fun();
  if (res.data.code === 0) {
    data.value = res.data.data;
    clickTop();
  } else {
    console.error(res.data.message);
  }
};  


// 电影搜索函数
const searchMovie = async () => {
  if(searchStr.value === "" && movieRegion.value === "" && movieType.value === "") return ; // 防止三空值搜索
  loading.value = true;
  try {
    const res = await searchMovieInfo({
      title: searchStr.value,
      region: movieRegion.value,
      type: movieType.value,
    });
    if (res.data.code === 0) {
      arr.value = res.data.data;
      // list.value.page = 1; // 重置页码
    }
  } catch (error) {
    console.error("搜索失败:", error);
  } finally {
    loading.value = false;
  }
};
// 点击电影业务埋点
const onCardClick = async (movie: Movie) => {
  localStorage.setItem("mvId" , movie.id)
  router.push({ name: "详细信息" });
  try {
    await ClickMovie(movie);
  } catch (error) {
    console.error("点击记录失败:", error);
  }
};

const clickTop = async () => {
  const res = await GetClickTop10();
  topMovie.value = res.data.data;
};

const handleCommand = async (command: string) => {
  switch (command) {
    case "userInfo":
      router.push("/userInfo");
      break;
    case "settings":
      router.push("/settings");
      break;
    case "logout":
      try {
        await ElMessageBox.confirm("确定要退出登录吗？", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        });
        // 退出登录传入用户id
        await UserLogout(localStorage.getItem("uId"));
        router.push("/");
      } catch {
        // 用户取消操作
      }
      break;
  }
};
const isCollapsed = ref(false);
const toggleCollapse = () => {
  isCollapsed.value = !isCollapsed.value;
};
defineProps({
  topMovie: {
    type: Array,
    required: true
  }
});
const emit = defineEmits(['item-click']);

// 滚动加载
const handleScroll = () => {
  const { scrollTop, clientHeight, scrollHeight } = document.documentElement;
  if (
    scrollTop + clientHeight >= scrollHeight - 200 &&
    !loading.value &&
    arr.value.length < total.value
  ) {
    list.value.page += 1;
    getMovie();
  }
};


onMounted(() => {
  getMovie();
  getList(getRegionList, region);
  getList(getTypeList, type);
  window.addEventListener("scroll", handleScroll);
  getUserInfo() 

});
onUnmounted(() => {
  window.removeEventListener("scroll", handleScroll);
});
if(store.type !== undefined ){
    movieType.value = store.type
    searchMovie()
  }
watch(() => ( movieType.value  , movieRegion.value ), () => {
  searchMovie()
});

</script> -->


<script lang="ts" setup>
import { ref, onMounted, onUnmounted, watch } from "vue";
import { useRouter, useRoute } from "vue-router";
import { ElMessage, ElMessageBox } from "element-plus";

import {
  MovieList,
  getRegionList,
  getTypeList,
  ClickMovie,
  getMovieCount,
  GetClickTop10,
  searchMovieInfo,
  UserLogout,
  GetUserInfo,
} from "@/views/api/index";

import type { Movie, Region, Type, Users } from "@/pojo/index";
import { useStore } from "@/pinia/index";

import { Search } from "@element-plus/icons-vue";

interface MvPage {
  page: number;
  size: number;
}

const router = useRouter();
const route = useRoute();
const store = useStore();

// 响应式变量定义
const arr = ref<Movie[]>([]);
const topMovie = ref<Movie[]>([]);
const list = ref<MvPage>({ page: 1, size: 12 });
const searchStr = ref("");
const loading = ref(false);
const region = ref<Region[]>([]);
const type = ref<Type[]>([]);
const total = ref(0);
const movieRegion = ref("");
const movieType = ref("");
const user = ref<Users | null>(null);

// 获取电影数据
const getMovie = async () => {
  loading.value = true;
  try {
    const res = await MovieList(list.value);
    const res2 = await getMovieCount();
    if (res.data.code === 0) {
      if (list.value.page === 1) {
        arr.value = res.data.data;
      } else {
        arr.value.push(...res.data.data);
      }
    }
    if (res2.data.code === 0) {
      total.value = res2.data.data;
    }
  } catch (error) {
    console.error("获取电影列表失败:", error);
  } finally {
    loading.value = false;
  }
};

// 获取用户信息
const getUserInfo = async () => {
  const uId = localStorage.getItem("uId");
  if (!uId) return;

  try {
    const res = await GetUserInfo(uId);
    if (res.data.code === 0) {
      user.value = res.data.data;
    } else {
      ElMessage.warning(res.data.message);
    }
  } catch (err) {
    console.error("获取用户信息失败:", err);
  }
};

// 获取地区和类型列表
const getList = async (fun: () => Promise<any>, data: any) => {
  try {
    const res = await fun();
    if (res.data.code === 0) {
      data.value = res.data.data;
      clickTop();
    } else {
      console.error(res.data.message);
    }
  } catch (error) {
    console.error("获取列表失败:", error);
  }
};

// 电影搜索函数
const searchMovie = async () => {
  if (
    searchStr.value.trim() === "" &&
    movieRegion.value === "" &&
    movieType.value === ""
  )
    return; // 防止三空值搜索
  loading.value = true;
  try {
    const res = await searchMovieInfo({
      title: searchStr.value,
      region: movieRegion.value,
      type: movieType.value,
    });
    if (res.data.code === 0) {
      arr.value = res.data.data;
      list.value.page = 1; // 搜索后重置页码
    }
  } catch (error) {
    console.error("搜索失败:", error);
  } finally {
    loading.value = false;
  }
};

// 点击电影业务埋点
const onCardClick = async (movie: Movie) => {
  if (movie.id) {
    localStorage.setItem("mvId", String(movie.id));
  }
  router.push({ name: "详细信息" });
  try {
    await ClickMovie(movie);
  } catch (error) {
    console.error("点击记录失败:", error);
  }
};

// 获取点击排行前十
const clickTop = async () => {
  try {
    const res = await GetClickTop10();
    if (res.data.code === 0) {
      topMovie.value = res.data.data;
    }
  } catch (error) {
    console.error("获取点击排行失败:", error);
  }
};

// 菜单命令处理
const handleCommand = async (command: string) => {
  switch (command) {
    case "userInfo":
      router.push("/userInfo");
      break;
    case "settings":
      router.push("/settings");
      break;
    case "logout":
      try {
        await ElMessageBox.confirm("确定要退出登录吗？", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        });
        await UserLogout(localStorage.getItem("uId") ?? "");
        router.push("/");
      } catch {
        // 用户取消操作
      }
      break;
  }
};

const isCollapsed = ref(false);
const toggleCollapse = () => {
  isCollapsed.value = !isCollapsed.value;
};

// 滚动加载
const handleScroll = () => {
  const { scrollTop, clientHeight, scrollHeight } = document.documentElement;
  if (
    scrollTop + clientHeight >= scrollHeight - 200 &&
    !loading.value &&
    arr.value.length < total.value
  ) {
    list.value.page += 1;
    getMovie();
  }
};

// 生命周期钩子
onMounted(() => {
  getMovie();
  getList(getRegionList, region);
  getList(getTypeList, type);
  window.addEventListener("scroll", handleScroll);
  getUserInfo();

  if (store.type !== undefined) {
    movieType.value = store.type;
    searchMovie();
  }
});

onUnmounted(() => {
  window.removeEventListener("scroll", handleScroll);
});

// 监听搜索筛选条件变化
watch(
  [() => movieType.value, () => movieRegion.value],
  () => {
    searchMovie();
  }
);
</script>




<style scoped lang="scss">
.floating-rank-list {
  position: fixed;
  top: 100px;
  right: 20px;
  width: 260px;
  background-color: #fff;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
  overflow: hidden;
  z-index: 100;
  transition: all 0.3s ease;
  
  &.collapsed {
    width: 60px;
    .rank-title, .collapse-icon {
      display: none;
    }
    .rank-header {
      justify-content: center;
      padding: 15px 0;
    }
  }

  .rank-header {
    display: flex;
    align-items: center;
    padding: 15px 20px;
    background-color: #f8f8f8;
    border-bottom: 1px solid #eee;
    cursor: pointer;
    user-select: none;
    transition: all 0.3s ease;

    &:hover {
      background-color: #f0f2f5;
    }

    .el-icon {
      color: #ff9900;
      font-size: 20px;
      margin-right: 8px;
      transition: all 0.3s ease;
    }

    .rank-title {
      margin: 0;
      font-size: 16px;
      font-weight: bold;
      color: #333;
      flex: 1;
      transition: all 0.3s ease;
    }

    .collapse-icon {
      color: #909399;
      font-size: 14px;
      margin-right: 0;
      transition: all 0.3s ease;
    }
  }

  .rank-item {
    display: flex;
    align-items: center;
    padding: 12px 20px;
    cursor: pointer;
    transition: all 0.3s ease;

    &:hover {
      background-color: #f5f7fa;
    }

    .rank-number {
      width: 24px;
      height: 24px;
      line-height: 24px;
      text-align: center;
      border-radius: 4px;
      background-color: #f0f2f5;
      color: #666;
      font-size: 14px;
      font-weight: bold;
      margin-right: 12px;
      flex-shrink: 0;
      transition: all 0.3s ease;

      &.top1 {
        background-color: #ffec3d;
        color: #f5222d;
      }

      &.top2 {
        background-color: #d9d9d9;
        color: #fa8c16;
      }

      &.top3 {
        background-color: #ffd591;
        color: #fa541c;
      }
    }

    .rank-content {
      flex: 1;
      min-width: 0;
      transition: all 0.3s ease;
    }

    .rank-movie-title {
      font-size: 14px;
      color: #333;
      font-weight: 500;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      margin-bottom: 4px;
      transition: all 0.3s ease;
    }

    .rank-meta {
      display: flex;
      align-items: center;
      transition: all 0.3s ease;
    }

    .rank-rating {
      :deep(.el-rate) {
        display: flex;
        align-items: center;
        transition: all 0.3s ease;

        .el-rate__item {
          margin-right: 2px;
        }

        .el-rate__text {
          color: #ff9900;
          font-size: 12px;
          margin-left: 6px;
          font-weight: bold;
        }
      }
    }
  }
}

@media (max-width: 992px) {
  .floating-rank-list {
    display: none;
  }
}

.app-container {
  position: relative;
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px 40px;
}

.app-header {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  height: 60px;
  padding: 0 20px;
  background-color: #fff;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}

.user-profile {
  .user-info {
    display: flex;
    align-items: center;
    padding: 4px 8px;
    border-radius: 20px;
    cursor: pointer;
    transition: all 0.3s;

    &:hover {
      background-color: rgba(0, 0, 0, 0.05);
    }

    .user-avatar {
      background-color: #409eff;
      color: white;
      margin-right: 8px;
    }

    .username {
      font-size: 14px;
      color: #333;
      margin-right: 4px;
      max-width: 100px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .el-icon--right {
      font-size: 12px;
      color: #909399;
    }
  }

  :deep(.el-dropdown-menu) {
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    padding: 8px 0;

    .el-dropdown-menu__item {
      display: flex;
      align-items: center;
      padding: 10px 16px;
      font-size: 14px;

      .el-icon {
        margin-right: 8px;
        font-size: 16px;
      }

      &:hover {
        background-color: #f5f7fa;
        color: #409eff;
      }
    }

    .el-dropdown-menu__item--divided {
      border-top: 1px solid #ebeef5;
      margin-top: 4px;
    }
  }
}

.main-content {
  display: flex;
  flex-direction: column;  /* 垂直排列 */
  align-items: center;     /* 水平居中对齐 */
  padding: 20px;
  justify-content: center; /* 垂直居中对齐 */ 
  min-height: 100vh;       /* 确保页面至少填充屏幕高度 */
}
.search-section {
  background-color: #fff;
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 20px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.05);
}

.search-container {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.search-input-container {
  display: flex;
  gap: 12px;

  .search-input {
    flex: 1;
    max-width: 500px;

    :deep(.el-input__wrapper) {
      border-radius: 20px;
      padding: 0 15px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    :deep(.el-input__prefix) {
      display: flex;
      align-items: center;
      padding-left: 10px;
    }
  }

  .search-button {
    border-radius: 20px;
    padding: 0 20px;
    height: 40px;
    font-weight: 500;
    transition: all 0.3s;

    &:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(64, 158, 255, 0.3);
    }
  }
}

.filters-container {
  display: flex;
  gap: 20px;
  flex-wrap: wrap;

  .filter-item {
    margin-bottom: 0;

    :deep(.el-form-item__label) {
      font-weight: 500;
      color: #606266;
    }
  }

  .filter-select {
    width: 200px;

    :deep(.el-input__wrapper) {
      border-radius: 20px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }
  }
}

.movie-list-section {
  margin-bottom: 30px;
}

.movie-list-container {
  margin-bottom: 20px;
}

.movie-list {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: center;
}


.movie-card {
  border-radius: 12px;
  overflow: hidden;
  transition: all 0.3s ease;  // 有平滑过渡动画
  border: none;
  height: 100%;

  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);  // 悬浮时上浮
  }

  :deep(.el-card__body) {
    padding: 0;
    height: 100%;
    display: flex;
    flex-direction: column;
  }
}

.movie-poster-container {
  position: relative;
  width: 100%;
  height: 0;
  padding-bottom: 140%;
  overflow: hidden;

  .movie-poster {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    transition: transform 0.5s;

    &:hover {
      transform: scale(1.05);
    }
  }

  .poster-error {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background-color: #f5f5f5;
    color: #999;

    .el-icon {
      font-size: 40px;
      margin-bottom: 10px;
    }
  }

  .movie-rating {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    padding: 10px;
    background: linear-gradient(transparent, rgba(0, 0, 0, 0.7));

    :deep(.el-rate) {
      display: flex;
      justify-content: center;

      .el-rate__item {
        margin-right: 2px;
      }

      .el-rate__text {
        color: #fff;
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.5);
        margin-left: 10px;
        font-weight: bold;
      }
    }
  }
}

.movie-info {
  padding: 15px;
  flex: 1;
  display: flex;
  flex-direction: column;
}

.movie-title {
  font-size: 16px;
  font-weight: bold;
  color: #333;
  margin: 0 0 8px 0;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  text-overflow: ellipsis;
  line-height: 1.4;

  .movie-year {
    color: #999;
    font-weight: normal;
    font-size: 14px;
    margin-left: 6px;
  }
}

.movie-meta {
  margin-top: auto;
  font-size: 13px;
  color: #666;

  .meta-item {
    display: flex;
    align-items: center;
    margin-bottom: 6px;

    .el-icon {
      margin-right: 6px;
      font-size: 14px;
    }

    .meta-text {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }
}

.loading-container,
.no-more {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 20px;
  color: #999;
  font-size: 14px;

  .loading-icon {
    margin-right: 8px;
    animation: rotating 2s linear infinite;
  }
}

.no-more {
  color: #666;
}

@keyframes rotating {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}


@media (max-width: 992px) {
  .floating-rank-list {
    display: none;
  }

  .movie-list {
    justify-content: flex-start;
  }
}

@media (max-width: 768px) {
  .search-section {
    padding: 15px;
  }

  .search-input-container {
    flex-direction: column;

    .search-input {
      max-width: 100%;
    }
  }

  .filters-container {
    flex-direction: column;
    gap: 10px;

    .filter-select {
      width: 100%;
    }
  }

  .movie-card {
    max-width: 100%;
  }
}

</style>