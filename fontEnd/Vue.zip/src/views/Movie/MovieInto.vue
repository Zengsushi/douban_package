<!-- <template>
  <el-container style="height: 100vh; background-color: #f0f2f5;">
    <el-header style="background-color: #1e88e5; color: white; display: flex; align-items: center; justify-content: center;">
      <h1 style="margin: 0; font-size: 24px;">电影详情</h1>
    </el-header>

    <el-main style="max-width: 1200px; margin: 0 auto; padding: 20px;">
      <el-row :gutter="24">
        <el-col :xs="24" :sm="8" :md="6">
          <div class="movie-poster">
            <el-image 
              :src="mvinfo.url" 
              alt="Movie Poster" 
              style="width: 100%; border-radius: 8px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);"
              fit="cover"
            />
          </div>
        </el-col>

        <el-col :xs="24" :sm="16" :md="18">
          <div class="movie-info">
            <h2 style="color: #333; margin-top: 0; font-size: 28px;">
              <template v-if="mvinfo.title">
                {{ mvinfo.title.split(" ")[0] }}
                <div v-if="mvinfo.title.split(' ').length > 1"> 
                   {{ mvinfo.title.split(" ").slice(1, -1).join(" ") }}
                </div>
              </template>
              <span style="color: #666; font-size: 20px;" v-if="mvinfo.year">({{ mvinfo.year }})</span>
            </h2>
            
            <div style="margin-bottom: 16px;">
              <el-tag v-if="mvinfo.score" type="warning" style="margin-right: 8px;">
                <span style="font-weight: bold;">{{ mvinfo.score }}</span>
              </el-tag>
              <el-tag v-for="(type, index) in (mvinfo.type ? mvinfo.type.split('/') : [])" :key="index" style="margin-right: 8px;">
                {{ type }}
              </el-tag>
            </div>

            <div class="info-item">
              <span class="info-label">时长：</span>
              <span class="info-content">{{ mvinfo.duration }}</span>
            </div>
            
            <div class="info-item">
              <span class="info-label">导演：</span>
              <span class="info-content">{{ mvinfo.director }}</span>
            </div>
            
            <div class="info-item">
              <span class="info-label">演员：</span>
              <span class="info-content">
                <span v-if="actor1 && mvinfo.actor">{{ mvinfo.actor.split("/")[0] }} &nbsp;</span>
                <el-link 
                  @click="toggleActors" 
                  type="primary" 
                  :underline="false" 
                  style="margin-left: 4px;"
                >
                  {{ bnt ? '显示更多...' : '隐藏' }}
                </el-link>
                <span v-if="actorInfo && mvinfo.actor" style="margin-left: 4px;">
                  <span v-for="(actor, index) in mvinfo.actor.split('/')" :key="index">
                    {{ actor }}<span v-if="index < mvinfo.actor.split('/').length - 1"> / </span>
                  </span>
                </span>
              </span>
            </div>
            
            <div class="info-item" style="margin-top: 16px;">
              <span class="info-label">简介：</span>
              <span class="info-content" style="line-height: 1.6; color: #555;">
                {{ mvinfo.description }}
              </span>
            </div>
          </div>
        </el-col>

        <el-col :span="24" style="margin-top: 32px;">
          <el-card shadow="hover">
            <div slot="header" class="clearfix">
              <h3 style="margin: 0; color: #333;">评论</h3>
            </div>
            
            <div v-if="comments.length === 0" style="text-align: center; padding: 20px; color: #888;">
              暂无评论，快来发表你的看法吧~
            </div>
            
            <div v-for="comment in comments" :key="comment.id" class="comment-item">
              <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="font-weight: 500; color: #1e88e5;">{{ comment.nickname }}:</div>
  
                <el-button v-if="comment.userId === userId"
                  type="text" 
                  size="mini" 
                  style="color: #f56c6c;"
                  @click="deleteComment(comment.id!)" 
                >
                  删除
                </el-button>
              </div>
              <div style="margin-top: 8px; color: #333; line-height: 1.5; margin-left:20px;" @click="comment.inputShow = !comment.inputShow">
                {{ comment.content }}
              </div> 

              <div v-if="comment.repliesShow && replies && Array.isArray(replies)" style="text-align: right; margin-bottom: 10px;">
                <span v-for="(rep, idx) in replies" :key="idx" style="background-color: #f0f0f0; padding: 6px 10px; border-radius: 8px; display: inline-block;">
                  {{ rep.nickname }} : {{ rep.content }}
                </span>
              </div> 

              <div v-if="comment.inputShow">
                <el-input 
                  v-model="repliesContext" 
                  type="textarea" 
                  placeholder="添加回复..." 
                />
                <div style="display: flex; justify-content: flex-end; margin-top: 8px;" >
                  <el-button 
                    size="small" 
                    @click="comment.inputShow = false; repliesContext = ''"
                  >
                    取消
                  </el-button>
                  <el-button 
                    type="primary" 
                    size="small" 
                    @click="submitReply(comment.id!); comment.inputShow = false"
                    style="margin-left: 8px;"
                  >
                    回复
                  </el-button>
                </div>
              </div>

              <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 8px;">
                <span v-if="typeof comment.reCount === 'number' && comment.reCount >= 0" style="font-size: 12px; color: #666;" >
                  {{ comment.reCount }}条回复
                  <a @click="getRapliesList(comment.id!); comment.repliesShow = !comment.repliesShow" v-if="!comment.repliesShow">展开</a>
                  <a @click="getRapliesList(comment.id!); comment.repliesShow = !comment.repliesShow" v-if="comment.repliesShow">收起</a>
                </span>
                <div v-if="comment.repliesShow" style="margin-top: 12px;"></div>
              </div>
            </div>
          </el-card>

          <el-card shadow="hover" style="margin-top: 20px;" >
            <div slot="header" class="clearfix">
              <h3 style="margin: 0; color: #333;">发表评论</h3>
            </div>
            
            <div class="comment-input-wrapper">
              <el-input 
                v-model="context" 
                :rows="3" 
                type="textarea" 
                placeholder="写下你的观后感..." 
              />
              <div style="display: flex; justify-content: flex-end; margin-top: 12px;">
                <el-button 
                  type="primary" 
                  size="small" 
                  @click="addComment"
                  :disabled="!context.trim()"
                >
                  提交评论
                </el-button>
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </el-main>
  </el-container>
</template> -->


<template>
  <el-container style="height: 100vh; background-color: #f0f2f5;">
    <!-- Header -->
    <el-header style="background-color: #1e88e5; color: white; display: flex; align-items: center; justify-content: center;">
      <h1 style="margin: 0; font-size: 24px;">电影详情</h1>
    </el-header>

    <!-- Main Content -->
    <el-main style="max-width: 1200px; margin: 0 auto; padding: 20px;">
      <el-row :gutter="24">
        <!-- Left: Movie Poster -->
        <el-col :xs="24" :sm="8" :md="6">
          <div class="movie-poster">
            <el-image 
              :src="mvinfo.url" 
              alt="Movie Poster" 
              style="width: 100%; border-radius: 8px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);"
              fit="cover"
            />
          </div>
        </el-col>

        <!-- Right: Movie Information -->
        <el-col :xs="24" :sm="16" :md="18">
          <div class="movie-info">
            <h2 style="color: #333; margin-top: 0; font-size: 28px;">
              <template v-if="mvinfo.title">
                {{ mvinfo.title.split(" ")[0] }}
                <div v-if="mvinfo.title.split(' ').length > 1"> 
                   {{ mvinfo.title.split(" ").slice(1, -1).join(" ") }}
                </div>
              </template>
              <span style="color: #666; font-size: 20px;" v-if="mvinfo.year">({{ mvinfo.year }})</span>
            </h2>
            
            <div style="margin-bottom: 16px;">
              <el-tag v-if="mvinfo.score" type="warning" style="margin-right: 8px;">
                <span style="font-weight: bold;">{{ mvinfo.score }}</span>
              </el-tag>
              <el-tag v-for="(type, index) in (mvinfo.type ? mvinfo.type.split('/') : [])" :key="index" style="margin-right: 8px;">
                {{ type }}
              </el-tag>
            </div>

            <div class="info-item">
              <span class="info-label">时长：</span>
              <span class="info-content">{{ mvinfo.duration }}</span>
            </div>
            
            <div class="info-item">
              <span class="info-label">导演：</span>
              <span class="info-content">{{ mvinfo.director }}</span>
            </div>
            
            <div class="info-item">
              <span class="info-label">演员：</span>
              <span class="info-content">
                <span v-if="actor1 && mvinfo.actor">{{ mvinfo.actor.split("/")[0] }} &nbsp;</span>
                <el-link 
                  @click="toggleActors" 
                  type="primary" 
                  :underline="false" 
                  style="margin-left: 4px;"
                >
                  {{ bnt ? '显示更多...' : '隐藏' }}
                </el-link>
                <span v-if="actorInfo && mvinfo.actor" style="margin-left: 4px;">
                  <span v-for="(actor, index) in mvinfo.actor.split('/')" :key="index">
                    {{ actor }}<span v-if="index < mvinfo.actor.split('/').length - 1"> / </span>
                  </span>
                </span>
              </span>
            </div>
            
            <div class="info-item" style="margin-top: 16px;">
              <span class="info-label">简介：</span>
              <span class="info-content" style="line-height: 1.6; color: #555;">
                {{ mvinfo.description }}
              </span>
            </div>
          </div>
        </el-col>

        <!-- Comments Section -->
        <el-col :span="24" style="margin-top: 32px;">
          <el-card shadow="hover">
            <div slot="header" class="clearfix">
              <h3 style="margin: 0; color: #333;">评论</h3>
            </div>
            
            <div v-if="comments.length === 0" style="text-align: center; padding: 20px; color: #888;">
              暂无评论，快来发表你的看法吧~
            </div>
            
            <div v-for="comment in comments" :key="comment.id" class="comment-item">
              <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="font-weight: 500; color: #1e88e5;">{{ comment.nickname }}:</div>
  
                <el-button v-if="comment.userId === userId"
                  type="text" 
                  size="mini" 
                  style="color: #f56c6c;"
                  @click="deleteComment(+comment.id!)"
                >
                  删除
                </el-button>
              </div>
              <div style="margin-top: 8px; color: #333; line-height: 1.5; margin-left:20px;" @click="comment.inputShow = !comment.inputShow">
                {{ comment.content }}
              </div> 

              <div v-if="comment.repliesShow && replies && Array.isArray(replies)" style="text-align: right; margin-bottom: 10px;">
                <span v-for="(rep, idx) in replies" :key="idx" style="background-color: #f0f0f0; padding: 6px 10px; border-radius: 8px; display: inline-block;">
                  {{ rep.nickname }} : {{ rep.content }}
                </span>
              </div> 

              <div v-if="comment.inputShow">
                <el-input 
                  v-model="repliesContext" 
                  type="textarea" 
                  placeholder="添加回复..." 
                />
                <div style="display: flex; justify-content: flex-end; margin-top: 8px;" >
                  <el-button 
                    size="small" 
                    @click="comment.inputShow = false; repliesContext = ''"
                  >
                    取消
                  </el-button>
                  <el-button 
                    type="primary" 
                    size="small" 
                    @click="submitReply(+comment.id!); comment.inputShow = false"
                    style="margin-left: 8px;"
                  >
                    回复
                  </el-button>
                </div>
              </div>

              <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 8px;">
                <span v-if="typeof comment.reCount === 'number' && comment.reCount >= 0" style="font-size: 12px; color: #666;" >
                  {{ comment.reCount }}条回复
                  <a @click="getRapliesList(+comment.id!); comment.repliesShow = !comment.repliesShow" v-if="!comment.repliesShow">展开</a>
                  <a @click="getRapliesList(+comment.id!); comment.repliesShow = !comment.repliesShow" v-if="comment.repliesShow">收起</a>
                </span>
                <div v-if="comment.repliesShow" style="margin-top: 12px;"></div>
              </div>
            </div>
          </el-card>

          <!-- Add Comment Section -->
          <el-card shadow="hover" style="margin-top: 20px;" >
            <div slot="header" class="clearfix">
              <h3 style="margin: 0; color: #333;">发表评论</h3>
            </div>
            
            <div class="comment-input-wrapper">
              <el-input 
                v-model="context" 
                :rows="3" 
                type="textarea" 
                placeholder="写下你的观后感..." 
              />
              <div style="display: flex; justify-content: flex-end; margin-top: 12px;">
                <el-button 
                  type="primary" 
                  size="small" 
                  @click="addComment"
                  :disabled="!context.trim()"
                >
                  提交评论
                </el-button>
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </el-main>
  </el-container>
</template>


<script lang="ts" setup>
import { onMounted, ref, watch } from "vue";
import { GetMvInfo, AddComments, AddReplies, GetComments, DeleteComments, GetReplies } from "@/views/api/index";

import type { Comments, Movie, Replies } from "@/pojo/index";

import { ElMessage, ElMessageBox } from 'element-plus';
import { useRoute } from 'vue-router';
const route = useRoute();

const mvinfo = ref<Movie>({});
const actorInfo = ref(false);
const bnt = ref(true);
const actor1 = ref(true);
const comments = ref<Comments[]>([]);
const context = ref("");
const repliesContext = ref("");
const replies = ref<Replies[]>([]); // 修改为数组，方便遍历
const userId = localStorage.getItem("uId");

const toggleActors = () => {
  actorInfo.value = !actorInfo.value;
  bnt.value = !bnt.value;
  actor1.value = !actor1.value;
};

// 获取电影详情
const getInfo = async () => {
  try {
    const res = await GetMvInfo({ id: localStorage.getItem("mvId") || "" });
    if (res.data.code === 0) {
      mvinfo.value = res.data.data;
    }
  } catch (error) {
    ElMessage.error('获取电影详情失败');
  }
};

const getRapliesList = async (commentId: number) => {
  const res = await GetReplies({ commentId });
  if (res.data.code === 0) {
    replies.value = res.data.data;
  }
};

// 评论回复
const submitReply = async (id: number) => {
  if (repliesContext.value === "") {
    ElMessage.warning('回复内容不能为空');
    return;
  }
  if (!userId) {
    ElMessage.warning('请先登录');
    return;
  }
  const res = await AddReplies({
    content: repliesContext.value,
    userId,
    commentId: id
  });
  if (res.data.code === 0) {
    ElMessage.success('回复成功');
    repliesContext.value = "";
    getCommentsList();
  } else {
    ElMessage.error('回复失败');
  }
};

// 获取评论列表
const getCommentsList = async () => {
  const mvId = localStorage.getItem("mvId");
  if (!mvId) return;
  try {
    const res = await GetComments({ mvId });
    if (res.data.code === 0) {
      comments.value = res.data.data;
    } else {
      ElMessage.warning(res.data.message);
    }
  } catch (error) {
    ElMessage.error('获取评论失败');
  }
};

// 发布评论
const addComment = async () => {
  if (!context.value.trim()) return;
  if (!userId) {
    ElMessage.warning('请先登录');
    return;
  }
  try {
    const res = await AddComments({
      mvId: localStorage.getItem("mvId") || "",
      content: context.value,
      userId
    });

    if (res.data.code === 0) {
      ElMessage.success('评论发布成功');
      context.value = "";
      getCommentsList();
    } else {
      ElMessage.error(res.data.message || '评论失败');
    }
  } catch (error) {
    ElMessage.error('评论发布失败');
  }
};

// 删除评论
const deleteComment = async (commentId: number) => {
  try {
    await ElMessageBox.confirm('确定要删除这条评论吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    });

    const res = await DeleteComments({ id: commentId });
    if (res.data.code === 0) {
      ElMessage.success('评论删除成功');
      getCommentsList();
    } else {
      ElMessage.error(res.data.message || '删除失败');
    }
  } catch (error) {
    // 用户点击了取消，忽略
  }
};

onMounted(() => {
  getInfo();
  getCommentsList();
});

watch(() => route.params.id, () => {
  getInfo();
  getCommentsList();
});
</script>

<style scoped>
body {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  color: #333;
  background-color: #f0f2f5;
}

.movie-info {
  padding: 18px;
  background-color: white;
  border-radius: 12px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
}

.info-item {
  margin-bottom: 16px;
  display: flex;
  align-items: center;
  font-size: 16px;
}

.info-label {
  color: #666;
  min-width: 80px;
  font-weight: 600;
  margin-right: 8px;
}

.info-content {
  color: #333;
  flex: 1;
}

.movie-poster {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  border-radius: 8px;
}

.movie-poster img {
  border-radius: 8px;
}

.el-tag {
  font-size: 13px;
  border-radius: 6px;
  padding: 4px 10px;
  background-color: #e3f2fd;
  color: #1976d2;
  border: none;
  margin-right: 8px;
}

.comment-item {
  padding: 16px;
  margin-bottom: 20px;
  background-color: #fff;
  border-radius: 8px;
  border: 1px solid #e0e0e0;
  transition: box-shadow 0.3s ease;
}

.comment-item:hover {
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
}

.comment-input-wrapper {
  padding: 16px;
  background-color: #f9f9f9;
  border-radius: 8px;
}

.comment-input-wrapper .el-input {
  padding: 10px;
  border-radius: 8px;
  background-color: #fff;
}

.el-button {
  border-radius: 6px;
  font-size: 14px;
  transition: all 0.2s ease-in-out;
  margin-left: 8px;
}

.el-button:hover {
  transform: scale(1.02);
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}

.el-input__inner {
  border-radius: 6px;
  padding: 10px;
  border: 1px solid #ccc;
  transition: border-color 0.3s;
}

.el-input__inner:focus {
  border-color: #1e88e5;
  box-shadow: 0 0 0 2px rgba(30, 136, 229, 0.1);
}

@media (max-width: 768px) {
  .movie-info {
    padding: 12px;
  }

  .info-item {
    flex-direction: column;
    align-items: flex-start;
    margin-bottom: 12px;
  }

  .info-label {
    margin-bottom: 6px;
    font-size: 14px;
  }

  .info-content {
    font-size: 14px;
  }

  .comment-item {
    padding: 12px;
  }

  .comment-input-wrapper {
    padding: 12px;
  }

  .el-input {
    padding: 8px;
  }

  .el-button {
    font-size: 14px;
    padding: 8px 12px;
  }

  .movie-poster {
    margin-bottom: 16px;
  }
}

@media (max-width: 480px) {
  .movie-info {
    padding: 8px;
  }

  .info-label {
    font-size: 12px;
    min-width: 60px;
  }

  .info-content {
    font-size: 12px;
  }

  .comment-item {
    padding: 10px;
  }

  .comment-input-wrapper {
    padding: 10px;
  }

  .el-input {
    padding: 6px;
  }

  .el-button {
    font-size: 12px;
    padding: 6px 10px;
  }

  .movie-poster {
    margin-bottom: 12px;
  }
}
</style>
