<template>
  <v-chart class="chart" :option="option" autoresize />
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import VChart from 'vue-echarts'
import { use } from 'echarts/core'
import { PieChart, type PieSeriesOption } from 'echarts/charts' // ✅ 这里改了
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  type LegendComponentOption,
  type TooltipComponentOption
} from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import type { ComposeOption } from 'echarts/core'

import { getBookPageCnt, getBookPrice } from '@/views/api/index'

use([
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  PieChart,
  CanvasRenderer
])

type EChartsOption = ComposeOption<
  PieSeriesOption | LegendComponentOption | TooltipComponentOption
>

// 初始图表配置
const option = ref<EChartsOption>({
  backgroundColor: 'transparent',
  tooltip: {
    trigger: 'item',
    formatter: '{a} <br/>{b}: {c} 本 ({d}%)'
  },
  legend: {
    orient: 'vertical',
    left: 10,
    top: 'center',
    textStyle: {
      color: 'aqua'
    },
    data: []
  } as LegendComponentOption,
  series: [
    {
      name: '书籍页数分布',
      type: 'pie',
      selectedMode: 'single',
      radius: [0, '30%'],
      label: {
        position: 'inner',
        fontSize: 12,
        color: 'aqua',
        formatter: '{d}%'
      },
      labelLine: { show: false },
      data: []
    },
    {
      name: '书籍价格分布',
      type: 'pie',
      radius: ['40%', '60%'],
      label: {
        formatter: '{b|{b}}\n{c} 本 ({d}%)',
        rich: {
          b: {
            fontSize: 12,
            lineHeight: 20,
            color: "aqua"
          }
        }
      },
      data: []
    }
  ] as PieSeriesOption[]
})

// 格式化后端数据
function formatData(raw: any[]): { name: string; value: number }[] {
  return raw.map((item: any) => ({
    name: item.name,
    value: Number(item.value)
  }))
}

// 加载数据
const loadChartData = async () => {
  try {
    const [pageRes, priceRes] = await Promise.all([
      getBookPageCnt(),
      getBookPrice()
    ])

    if (pageRes.data.code === 0 && priceRes.data.code === 0) {
      const pageData = formatData(pageRes.data.data)
      const priceData = formatData(priceRes.data.data)

      // ✅ 更新图表数据
      ;(option.value.series as PieSeriesOption[])[0].data = pageData
      ;(option.value.series as PieSeriesOption[])[1].data = priceData

      // ✅ 图例合并
      ;(option.value.legend as LegendComponentOption).data = [
        ...pageData.map((i: { name: string }) => i.name),
        ...priceData.map((i: { name: string }) => i.name)
      ]
    }
  } catch (error) {
    console.error('图表数据加载失败:', error)
  }
}

onMounted(() => {
  loadChartData()
})
</script>

<style scoped>
.chart {
  width: 100%;
  height: 400px;
}
</style>
