<template>
  <div class="word-cloud-container">
    <VChart class="chart" :option="option" :autoresize="true" />
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted } from 'vue'
import { use } from 'echarts/core'
import VChart from 'vue-echarts'
import type { Data } from '@/pojo/index'
import { CanvasRenderer } from 'echarts/renderers'
import { TooltipComponent } from 'echarts/components'
import { getBookPress } from '@/views/api/index'
import 'echarts-wordcloud'

// 正确注册 ECharts 所需模块（不要使用 MapSeriesOption）
use([
  CanvasRenderer,
  TooltipComponent
])

// 初始展示数据（可为空）
const wordData = ref<Data[]>([])

const option = ref({
  tooltip: {
    show: true,
    formatter: '{b}: {c}'
  },
  series: [
    {
      type: 'wordCloud',
      shape: 'circle',
      left: 'center',
      top: 'center',
      width: '100%',
      height: '100%',
      gridSize: 8,
      sizeRange: [10, 40],
      rotationRange: [0, 90],
      drawOutOfBound: true,
      textStyle: {
        fontFamily: 'sans-serif',
        color: () => {
          // 更简洁的随机色生成
          return `hsl(${Math.random() * 360}, 70%, 60%)`
        }
      },
      data: wordData.value
    }
  ]
})

const getCityData = async () => {
  try {
    const res = await getBookPress()
    console.log(res.data.data);
    
    if (res.data.code === 0) {
      const updatedData = res.data.data.map((item: Data) => ({
        name: item.name,
        value: item.value
      }))
      wordData.value = updatedData

      const seriesArray = option.value.series
      if (Array.isArray(seriesArray)) {
        seriesArray[0].data = updatedData
      }
    } else {
      console.error('接口返回失败：', res.data.msg)
    }
  } catch (error) {
    console.error('请求失败：', error)
  }
}

// 页面加载时调用
onMounted(() => {
  getCityData()
})
</script>

<style scoped>
.word-cloud-container {
  /* width: 100%; */
  min-width: 500px;
  height: 380px;
}

.chart {
  width: 100%;
  height: 100%;
}
</style>
