<template>
  <div class="content">
    <v-chart class="chart" :option="option" autoresize v-if="isMounted" />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import VChart from 'vue-echarts'
import { use } from 'echarts/core'
import { PieChart } from 'echarts/charts'
import {
  ToolboxComponent,
  TitleComponent,
  TooltipComponent,
  LegendComponent
} from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import type { ComposeOption } from 'echarts/core'
import type { PieSeriesOption } from 'echarts/charts'
import type {
  ToolboxComponentOption,
  TitleComponentOption,
  TooltipComponentOption,
  LegendComponentOption
} from 'echarts/components'
import { getBookTypeCnt } from '@/views/api/index'

// 注册 ECharts 组件
use([
  ToolboxComponent,
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  PieChart,
  CanvasRenderer
])

type EChartsOption = ComposeOption<
  | ToolboxComponentOption
  | TitleComponentOption
  | TooltipComponentOption
  | LegendComponentOption
  | PieSeriesOption
>

const isMounted = ref(false)
onMounted(() => {
  isMounted.value = true
})

// 颜色梯度配置
const colors = [
  ['#2E91FF', '#7CBAFF'],
  ['#64A1CE', '#87C4E7'],
  ['#30D4B7', '#95FFEC'],
  ['#92DA59', '#CEFE91'],
  ['#FFC554', '#FFD771'],
  ['#F98C6A', '#F6AF9F']
]

const data = ref<any[]>([])

// 初始 ECharts 配置
const option = ref<EChartsOption>({
  toolbox: {
    show: true,
    feature: {
      saveAsImage: {
        show: true,
        title: '保存图片',
        pixelRatio: 2,
        backgroundColor: 'transparent'
      }
    }
  },
  title: {
    show: true,
    text: '类型分析',
    top: '5%',
    left: 'center',
    textStyle: {
      color: '#fff',
      fontSize: 18,
      fontWeight: 'bold'
    }
  },
  tooltip: {
    trigger: 'item',
    formatter: (params: any) => `
      <div style="margin-bottom:5px;font-weight:bold">${params.name}</div>
      <div>书籍类型数量: ${params.value}</div>
      <div>占比: ${params.percent}%</div>
    `,
    backgroundColor: 'rgba(0,0,0,0.8)',
    borderColor: 'rgba(255,255,255,0.3)',
    textStyle: {
      color: 'aqua',
      fontSize: 14
    }
  },
  legend: {
    type: 'scroll',
    orient: 'vertical',
    right: '5%',
    top: 'middle',
    textStyle: {
      color: 'aqua'
    },
    icon: 'circle',
    itemWidth: 10,
    itemHeight: 10,
    itemGap: 15
  },
  series: [
    {
      type: 'pie',
      radius: ['20%', '80%'],
      center: ['40%', '50%'],
      roseType: 'radius',
      startAngle: 30,
      avoidLabelOverlap: true,
      itemStyle: {
        borderRadius: 5,
        borderColor: '#10398a',
        borderWidth: 2
      },
      label: {
        show: true,
        position: 'outside',
        formatter: '{b}\n{c}  ({d}%)',
        color: 'aqua',
        fontSize: 12,
        fontWeight: 'normal',
        lineHeight: 18
      },
      labelLine: {
        show: true,
        length: 15,
        length2: 20,
        smooth: 0.2,
        lineStyle: {
          width: 1,
          color: '#00ffff'
        }
      },
      emphasis: {
        label: {
          show: true,
          fontSize: 14,
          fontWeight: 'bold'
        },
        itemStyle: {
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 0, 0, 0.5)'
        }
      },
      data: []
    }
  ]
})

// 获取图表数据
const getTypeCnt = async () => {
  const res = await getBookTypeCnt()
  if (res.data.code === 0) {
    data.value = res.data.data.map((item: any) => ({
      name: item.name,
      value: item.value
    }))
  }
}

// 数据更新后更新图表
watch(data, (newVal) => {
  if (
    Array.isArray(option.value.series) &&
    option.value.series.length > 0
  ) {
    option.value.series[0] = {
      ...option.value.series[0],
      data: newVal.map((item, index) => ({
        ...item,
        itemStyle: {
          color: {
            type: 'linear',
            x: 0, y: 0, x2: 0, y2: 1,
            colorStops: [
              { offset: 0, color: colors[index % colors.length][0] },
              { offset: 1, color: colors[index % colors.length][1] }
            ]
          }
        }
      }))
    }
  }
}, { deep: true })

onMounted(() => {
  getTypeCnt()
})
</script>

<style scoped>
.content {
  min-width: 500px;
  height: 450px;
  /* position: relative; */
}

.chart {
  width: 100%;
  height: 100%;
  min-height: 400px;
}
</style>
