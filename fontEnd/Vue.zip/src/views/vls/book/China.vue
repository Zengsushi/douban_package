<template>
  <div class="content">
    <v-chart class="chart" :option="option" autoresize />
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';
import VChart from 'vue-echarts';
import { use } from 'echarts/core';
import { MapChart } from 'echarts/charts';
import { GeoComponent, TooltipComponent } from 'echarts/components';
import { CanvasRenderer } from 'echarts/renderers';
import * as echarts from 'echarts/core';
import china from '@/assets/china.json'; // GeoJSON 文件
import { getBookData } from "@/views/api/index"; // 数据请求
import type { Data } from "@/pojo/index"
import type { ComposeOption } from 'echarts/core';
import type { MapSeriesOption } from 'echarts/charts';
import type { GeoComponentOption, TooltipComponentOption } from 'echarts/components';

type EChartsOption = ComposeOption<
  | GeoComponentOption
  | TooltipComponentOption
  | MapSeriesOption
>

use([MapChart, GeoComponent, TooltipComponent, CanvasRenderer]);

echarts.registerMap('china', china as any);

const data = ref<Data[]>([]);
const option = ref<EChartsOption>({
  backgroundColor: 'rgb(14, 26, 59)',
  tooltip: {
    trigger: 'item',
    formatter: (params: any) => `${params.name}: ${params.value ?? '无数据'}`
  },
  geo: {
    map: 'china',
    label: {
      show: true,
      color: '#fff',
    },
    itemStyle: {
      borderColor: '#5089EC',
      borderWidth: 1,
      areaColor: {
        type: 'radial',
        x: 0.5,
        y: 0.5,
        r: 0.8,
        colorStops: [
          { offset: 0, color: 'rgba(0,102,154,0)' },
          { offset: 1, color: 'rgba(0,102,154,0)' }
        ]
      }
    }
  },
  series: [{
    type: 'map',
    map: 'china',
    geoIndex: 0,
    data: [] // 初始化为空数组
  }]
});

// 获取城市数据并更新图表
const getCityData = async () => {
  try {
    const res = await getBookData();
    if (res.data.code === 0) {
      const updatedData = res.data.data.map((item: Data) => ({
        name: item.name,
        value: item.value
      }));

      // ✅ 类型断言确保是 MapSeriesOption[]
      const seriesArray = option.value.series as MapSeriesOption[];
      if (Array.isArray(seriesArray)) {
        seriesArray[0].data = updatedData;
      }
    } else {
      console.error("接口调用失败");
    }
  } catch (error) {
    console.error("获取数据失败", error);
  }
};

// 挂载时获取数据
onMounted(() => {
  getCityData();
});
</script>

<style scoped>
.content {
  padding-left: -100px ;
  background-color: rgb(14, 26, 59);
  min-width: 600px;
  width: 100%;
  margin: 0 auto;
}

.chart {
  width: 100%;
  height: 500px;
}
</style>
