<template>
  <div style="display: flex;">
    <v-chart class="chart" :option="option" autoresize v-if="!loading" @click="handleChartClick" />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { getBookYearCnt } from '@/views/api/index'
import VChart from 'vue-echarts'
import { use } from 'echarts/core'
import { LineChart } from 'echarts/charts'
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  DataZoomComponent
} from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'

use([
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  DataZoomComponent,
  LineChart,
  CanvasRenderer
])

const option = ref({
  backgroundColor: 'transparent',
  title: {
    text: '年度书籍统计',
    left: 'center',
    textStyle: {
      color: '#333',
      fontSize: 18,
      fontWeight: 'bold'
    }
  },
  tooltip: {
    trigger: 'axis',
    axisPointer: {
      type: 'shadow'
    },
    formatter: (params: any[]) => {
      let result = `<div style="font-weight:bold;margin-bottom:5px">${params[0].axisValue} 年</div>`
      params.forEach((item) => {
        result += `
          <div style="display:flex;align-items:center;margin:3px 0">
            <span style="display:inline-block;width:10px;height:10px;background:${item.color};margin-right:5px"></span>
            ${item.seriesName}: <strong>${item.value}</strong>
          </div>`
      })
      return result
    }
  },
  legend: {
    data: ['书籍数量'],
    top: 30,
    textStyle: {
      color: '#666',
      fontSize: 12
    }
  },
  grid: {
    left: '3%',
    right: '4%',
    bottom: '15%',
    top: '20%',
    containLabel: true
  },
  xAxis: {
    type: 'category',
    data: [] as string[],
    axisLine: {
      lineStyle: {
        color: '#ccc'
      }
    },
    axisLabel: {
      color: '#666'
    }
  },
  yAxis: {
    type: 'value',
    axisLine: {
      show: true,
      lineStyle: {
        color: '#ccc'
      }
    },
    axisLabel: {
      color: '#666'
    },
    splitLine: {
      lineStyle: {
        type: 'dashed',
        color: '#eaeaea'
      }
    }
  },
  dataZoom: [
    { type: 'inside', start: 0, end: 100 },
    { start: 0, end: 100, bottom: 5, height: 20 }
  ],
  series: [
    {
      name: '书籍数量',
      type: 'line',
      smooth: true,
      symbol: 'circle',
      symbolSize: 8,
      lineStyle: {
        width: 3,
        color: '#5470C6'
      },
      itemStyle: {
        color: '#5470C6'
      },
      areaStyle: {
        color: {
          type: 'linear',
          x: 0, y: 0, x2: 0, y2: 1,
          colorStops: [
            { offset: 0, color: 'rgba(84, 112, 198, 0.5)' },
            { offset: 1, color: 'rgba(84, 112, 198, 0.1)' }
          ]
        }
      },
      data: [] as number[]
    }
  ]
})

const loading = ref(true)

const handleChartClick = (params: any) => {
  console.log('Chart clicked:', params)
}

const getOptionData = async () => {
  try {
    loading.value = true
    const res = await getBookYearCnt()
    const raw = res?.data?.data

    if (res.data.code === 0 && Array.isArray(raw)) {
      const years = raw.map((item) => item.name)
      const values = raw.map((item) => item.value)

      option.value.xAxis = { ...(option.value.xAxis as any), data: years }
      option.value.series[0].data = values
    }
  } catch (e) {
    console.error('获取图表数据失败:', e)
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  getOptionData()
})
</script>

<style scoped>
.chart {
  width: 100%;
  min-height: 380px;
}
</style>
