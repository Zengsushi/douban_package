<template>
  <div class="dashboard-container">
    <div class="header">
      <h1>书籍</h1>
      <div  style="display: flex;">
        <el-icon class="icon" @click="router.push('/home') "><HomeFilled /></el-icon>
        <!-- <el-icon class="icon" v-if="type"  @click="router.push('/BookVls')" ><Notebook /></el-icon> -->
        <el-icon class="icon" v-if="type"  @click="router.push('/MovieVls')"><VideoCameraFilled /></el-icon>
      </div>
      <div class="time">{{ currentTime }}</div>
    </div>
    
    <div class="dashboard-content">
      <!-- 左侧面板 -->
      <div class="left-panel">
            <!-- 平滑折线图 -->
        <el-card class="chart-card">
                <Line />
        </el-card>
        <el-card class="chart-card">
          <!--  柱状图 -->
          <div>
              <Rose /> 
          </div>
        </el-card>
      </div>
      

      <!-- 中间面板 -->
      <div class="center-panel">
        <el-card class="chart-card map-container">
          <!-- 数量统计 -->
          <!-- <div style="display: flex; justify-content: center;" > -->
            <Num :name="'全部'" :number=NumberData  />
          <!-- </div>  -->
          <div style="display: flex; justify-content: center;" >
            <Num :name="'国内'" :number=NumberData1 />
            <Num :name="'国外'"  :number=NumberData2  />
          </div> 
          <!-- 旭日图 -->
          <div>
            <China />
          </div>

        </el-card>
      </div>
      
      <!-- 右侧面板 -->
      <div class="right-panel" >
        <el-card class="chart-card">
          <!-- 右上饼图 -->
          <!-- <div class="pie-row" v-if="Picdata || Picdata1">
            <div v-if="Picdata" style="max-width: 300px;">
              <Pie :data=Picdata :title="'时长分布'" />   
            </div> 
            <div v-if="Picdata1">
              <Pie :data=Picdata1 :name="'星'" :title="'评分分布'" />   
            </div> 
          </div> -->
          <!-- 右下字云图 -->
          <div >
           <PressWordClound />
          </div>
        </el-card>
        <el-card class="chart-card">
            <!-- <Bar :data=Bardata /> -->
          <Bar2 />
        </el-card>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted , onBeforeMount , watch } from 'vue'

import China from "@/views/vls/book/China.vue"
import Rose from "@/views/vls/book/Rose.vue"
import PressWordClound from "@/views/vls/book/bookWordCloud.vue"
import Num from "@/views/vls/module/Num.vue"
import Funnel from "@/views/vls/module/Funnel.vue"
import Line from "@/views/vls/book/Line.vue"
import router from "@/router";
import Bar2 from "@/views/vls/book/Bar2.vue"


import { getCategory  , GetTypeCnt , getScoreCnt  ,  GetRegionCnt, 
  getScore , getRegionCnt , getMvScoreCntTop25
} from "../api/index"




const Picdata = ref()
const Wordclound = ref()
const Bardata = ref()
const Picdata1 = ref()
const NumberData = ref() 
var NumberData1 = ref() 
var NumberData2 = ref()
const Funneldata = ref()

const type = ref(true)



const currentTime = ref(new Date().toLocaleString())
let timer: number

// 饼
const PicData = async (fun : Function , data : any) => {
  const res = await fun()
  if( res.data.code === 0 ){
    data.value = res.data.data
  }
}
// 字云
const WordCloudData = async () => {
  const res = await GetTypeCnt()
  if( res.data.code === 0 ){
    Wordclound.value = res.data.data
  }
}
// 柱状 
const BarData = async () => {
  const res = await getScoreCnt() 
  if(res.data.code === 0 ){
    Bardata.value = res.data.data
  }
}
// 翻牌器
const NumData = async () => {
  const res = await getRegionCnt() 
  if( res.data.code === 0 ){
    NumberData1.value= res.data.data[0].value
    NumberData2.value= res.data.data[1].value
    NumberData.value = NumberData1.value + NumberData2.value
  }  
}

// 漏斗图
const FunnelData =  async () => {
  const res = await getMvScoreCntTop25()
  if(res.data.code === 0){
    Funneldata.value = res.data.data
  }
}



onBeforeMount ( () => {
  PicData(getCategory ,Picdata )
  PicData(getScore ,Picdata1 )
  WordCloudData() 
  BarData() 
  NumData() 
  FunnelData() 
})

onMounted(() => {
  timer = window.setInterval(() => {
    currentTime.value = new Date().toLocaleString()
  }, 1000)
  // if(!localStorage.getItem("uId")){
  //   router.push('/login')
  // }
})

onUnmounted(() => {
  clearInterval(timer)
})

</script>

<style scoped lang="scss">
.dashboard-container {
  min-height: 100vh;
  min-width: 100vh;
  background: #0f1c3c;
  color: #fff;
  padding: 20px;
  box-sizing: border-box;
  
  .header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    // margin-bottom: 10px;
    
    h1 {
      margin: 0;
      font-size: 24px;
      background: linear-gradient(to right, #30cfd0, #c43ad6);
      -webkit-background-clip: text;
      color: transparent;
    }
    
    .time {
      font-size: 16px;
      color: #30cfd0;
    }
  }
  
  .dashboard-content {
    display: grid;
    grid-template-columns: 1fr 1.5fr 1fr;
    gap: 20px;
    height: calc(100vh - 100px);
    min-width: 400px;
    min-width: 500px;
    .left-panel,
    .right-panel {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }
    
    .chart-card {
      flex: 1;
      background: rgba(13, 25, 58, 0.8);
      border: 1px solid rgba(48, 207, 208, 0.1);
      width: 500px;
      :deep(.el-card__body) {
        height: 98%;
        padding: 8px;
      }

    }
    .map-container {
      height: 100%;
      min-width: 580px;
    }
  }
}

:deep(.el-card) {
  background: transparent;
  border: none;
  color: #fff;
  overflow: visible !important;
  position: relative;
  box-shadow: none;
}

.pie-row {
  display: flex;
  // justify-content: space-around;
  align-items: center;
  gap: 20px;

  > div {
    flex: 1;
  }
}

.icon{
  margin: 8px;
}


</style>