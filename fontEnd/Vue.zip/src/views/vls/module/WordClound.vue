<template>
  <div class="word-cloud-container">
    <VChart
      class="chart"
      :option="option"
      :autoresize="true"
      @Click="handleClick"
    />
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted } from 'vue'
import { use } from 'echarts/core'
import { CanvasRenderer } from 'echarts/renderers'
import { PieChart, BarChart } from 'echarts/charts' // 引入基础图表
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent
} from 'echarts/components'
import VChart from 'vue-echarts'
import 'echarts-wordcloud' // 引入词云扩展
import router from "@/router/index"
import { useStore } from '@/pinia/index'

const store = useStore()


// 注册必要的组件
use([
  CanvasRenderer,
  PieChart,
  BarChart,
  TitleComponent,
  TooltipComponent,
  LegendComponent
])

const option = ref<any>({
  tooltip: {
    show: true,
    formatter: '{b}: {c}'
  },
  series: [{
      type: 'wordCloud',
      data: []
  }]
})

// 接收父组件传参
const data = defineProps ({
  data : {
    type: Object,
    required: true
  }
})
option.value.series[0].data = data.data

const handleClick = (params: any) => {
  store.setSearchStr(params.data.name)
  router.push("/movies")
}

</script>



<style scoped>
.word-cloud-container {
  width: 100%;
  height: 240px;
}

.chart {
  width: 100%;
  height: 100%;
}
</style>