<template>
  <div class="word-cloud-container">
    <VChart
      class="chart"
      :option="option"
      :autoresize="true"
      @click="handleClick"
    />
  </div>
</template>

<script lang="ts" setup>
import { ref, watch, onMounted } from 'vue';
import { use } from 'echarts/core';
import { CanvasRenderer } from 'echarts/renderers';
import { PieChart, BarChart } from 'echarts/charts';
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent
} from 'echarts/components';
import VChart from 'vue-echarts';
import 'echarts-wordcloud'; // 必须引入词云扩展
import { useStore } from "@/pinia/index";
import router from "@/router/index";

// 注册组件
use([
  CanvasRenderer,
  PieChart,
  BarChart,
  TitleComponent,
  TooltipComponent,
  LegendComponent
]);

// 引入图片（放在 src/assets/type-mask.png）
import typeMask from '@/assets/type-mask.png';

const store = useStore();

const props = defineProps({
  data: {
    type: Object,
    required: true
  }
});

const option = ref({
  gridSize: 0,      
  sizeRange: [10, 30],      // ✅ 减小字体大小范围，避免过大造成空隙
  rotationStep: 0,          // ✅ 统一方向也能提高密集度
  drawOutOfBound: true,     // ✅ 允许越界绘制，提升边缘密度
  layoutAnimation: false,   // ✅ 禁用动画，加载更快
  shrinkToFit: true ,      
  tooltip: {
    show: true,
    formatter: '{b}: {c}'
  },
  series: [
    {
      type: 'wordCloud',
      shape: 'circle', // shape会被maskImage覆盖
      gridSize: 2,
      sizeRange: [12, 60],
      rotationRange: [-90, 90],
      rotationStep: 45,
      maskImage: null as any,
      textStyle: {
        fontFamily: 'sans-serif',
        fontWeight: 'bold',
        color: () =>
          `rgb(${Math.round(Math.random() * 160)}, ${Math.round(
            Math.random() * 160
          )}, ${Math.round(Math.random() * 160)})`,
        textBorderColor: 'transparent',
        textBorderWidth: 0
      },
      data: [] as Record<string, any>
    }
  ]
});

const handleClick = (params: any) => {
  store.setSearchStr(params.data.name);
  router.push('/movies');
};

onMounted(() => {
  const img = new Image();
  img.src = typeMask;
  img.onload = () => {
    option.value.series[0].maskImage = img;
    option.value.series[0].data = props.data;
  };
});
</script>

<style scoped>
.word-cloud-container {
  width: 100%;
  height: 320px;
}

.chart {
  width: 100%;
  height: 100%;
}
</style>
a