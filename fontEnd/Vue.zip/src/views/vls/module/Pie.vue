<template>
  <div style="display: flex;;">
    <v-chart class="chart" :option="option" autoresize />
  </div>
</template>

<script lang="ts" setup>

import { use } from "echarts/core"
import { CanvasRenderer } from "echarts/renderers"
import { PieChart } from "echarts/charts";
import { TitleComponent, TooltipComponent, LegendComponent } from "echarts/components";
import VChart, { THEME_KEY } from 'vue-echarts';
import { ref, onMounted, provide } from 'vue';


use([
CanvasRenderer,
PieChart,
TitleComponent,
TooltipComponent,
LegendComponent,
]);
provide(THEME_KEY, "dark")

const props = defineProps({
  data : {
    type : Object,
    required : true
  },
  // 可选参数
  name : {
    type : String,
    default : ""
  },
  title : {
    type : String , 
    default : ""
  } ,
  fontColor : {
      type : String,
      default : "aquamarine"
  }
})


const option = ref({
backgroundColor: 'transparent',  // 设置背景透明
title: {
  text  : props.title ,
  left: 'center',
},
label: {
  show: true,
  color: props.fontColor,
  fontSize: 14,
  textBorderColor: 'transparent', 
  textBorderWidth: 0              
},
tooltip: {
  trigger: 'item',
},
legend: {
  orient: 'vertical',
  left: 'left',
  data: [],
},
series: [
  {
    name: '时长分布',
    type: 'pie',
    radius: '50%',
    center: ['50%', '50%'],
    data: [],
    emphasis: {
      itemStyle: {
        shadowBlur: 10,
        shadowOffsetX: 0,
        shadowColor: 'rgba(0, 0, 0, 0.5)',
      },
    },
  },
],
});


option.value.series[0].data = props.data.map((item: { value: number; name: string; }) => {
  return {
    value: item.value ,
    name: item.name + props.name
  }
})

// console.log(option.value.series[0].data);

// const getCategoryData = async () => {
// const res = await getCategory()
// option.value.series[0].data = res.data.data.map((item: { category_cnt: number; category: string; }) => {
//   return {
//     value: item.category_cnt,
//     name: item.category
//   }
// })
// }
// getCategoryData()  
// onMounted(() => {
 
// })
</script>

<style scoped>

.chart {
height: 200px;
width: 250px;
}
</style>
