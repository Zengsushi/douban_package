<template>
  <v-chart class="chart" :option="option" autoresize />
</template>

<script lang="ts" setup>
import VChart from 'vue-echarts';
import { ref } from 'vue';
import { use } from 'echarts/core';
import { BarChart } from 'echarts/charts';
import {
  GridComponent,
  TooltipComponent,
  DataZoomComponent,
  VisualMapComponent,
  type GridComponentOption,
  type TooltipComponentOption,
  type DataZoomComponentOption,
  type VisualMapComponentOption
} from 'echarts/components';
import { CanvasRenderer } from 'echarts/renderers';
import type { ComposeOption } from 'echarts/core';
import type { BarSeriesOption } from 'echarts/charts';

// 注册 ECharts 所需组件
use([
  GridComponent,
  BarChart,
  CanvasRenderer,
  TooltipComponent,
  DataZoomComponent,
  VisualMapComponent
]);

// 定义图表选项类型
type EChartsOption = ComposeOption<
  BarSeriesOption |
  GridComponentOption |
  TooltipComponentOption |
  DataZoomComponentOption |
  VisualMapComponentOption
>;

// 初始配置项
const option = ref<EChartsOption>({
  backgroundColor: 'transparent',
  color: ['#3a86ff', '#8338ec', '#ff006e', '#fb5607', '#ffbe0b'],
  tooltip: {
    trigger: 'axis',
    axisPointer: {
      type: 'shadow',
      shadowStyle: {
        color: 'rgba(0, 0, 0, 0.05)'
      }
    },
    className: 'modern-tooltip',
    borderWidth: 0,
    borderRadius: 8,
    padding: [10, 15],
    textStyle: {
      fontSize: 12,
      fontWeight: 500,
      color: '#495057'
    },
    extraCssText: 'box-shadow: 0 4px 20px rgba(0,0,0,0.1);'
  },
  grid: {
    left: '5%',
    right: '5%',
    bottom: '15%',
    top: '10%',
    containLabel: true
  },
  xAxis: {
    type: 'category',
    axisLine: {
      lineStyle: {
        color: '#e9ecef'
      }
    },
    axisTick: {
      alignWithLabel: true,
      lineStyle: {
        color: '#e9ecef'
      }
    },
    axisLabel: {
      color: '#6c757d',
      fontSize: 11,
      margin: 15
    },
    splitLine: {
      show: false
    }
  },
  yAxis: {
    type: 'value',
    axisLine: {
      show: false
    },
    axisTick: {
      show: false
    },
    axisLabel: {
      color: '#6c757d',
      fontSize: 11
    },
    splitLine: {
      lineStyle: {
        color: '#e9ecef',
        type: 'dashed'
      }
    }
  },
  emphasis: {
    itemStyle: {
      shadowBlur: 10,
      shadowOffsetX: 0,
      shadowColor: 'rgba(0, 0, 0, 0.5)'
    }
  },
  // 全局动画放这里
  animationType: 'scale',
  animationEasing: 'elasticOut',
  animationDelay: (idx: number) => idx * 100,
  series: [{
    name: '数量',
    type: 'bar',
    barWidth: '70%',
    data: [], // 初始空数据，稍后赋值
    itemStyle: {
      borderRadius: [6, 6, 0, 0],
      borderWidth: 0,
      shadowColor: 'rgba(0,0,0,0.1)',
      shadowBlur: 6,
      shadowOffsetY: 3
    },
    label: {
      show: true,
      position: 'top',
      distance: 10,
      color: '#495057',
      fontSize: 10,
      fontWeight: 600,
      formatter: '{c}'
    },
    emphasis: {
      itemStyle: {
        shadowColor: 'rgba(0,0,0,0.2)',
        shadowBlur: 8,
        shadowOffsetY: 4,
        opacity: 0.9
      }
    }
  }],
  dataZoom: [{
    type: 'slider',
    show: true,
    height: 15,
    bottom: 25,
    borderColor: 'transparent',
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    fillerColor: 'rgba(58, 134, 255, 0.2)',
    handleSize: '80%',
    handleStyle: {
      color: '#3a86ff',
      shadowBlur: 3,
      shadowColor: 'rgba(58, 134, 255, 0.3)',
      shadowOffsetX: 1,
      shadowOffsetY: 1
    },
    textStyle: {
      color: '#6c757d'
    },
    brushSelect: false
  }, {
    type: 'inside'
  }],
  visualMap: {
    type: 'continuous',
    min: 0,
    max: 100,
    inRange: {
      colorLightness: [0.4, 0.8]
    },
    calculable: true,
    hoverLink: false,
    orient: 'horizontal',
    left: 'center',
    bottom: 0,
    textStyle: {
      color: '#6c757d'
    }
  }
});

// Props 类型，要求传入数据格式
const data = defineProps({
  data: {
    type: Array as () => { name: string; value: number }[],
    required: true
  }
});

// 初始化图表数据函数
const initChart = () => {
  const name = data.data.map(item => item.name);
  const value = data.data.map(item => item.value);

  option.value = {
    ...option.value,
    xAxis: {
      ...option.value.xAxis,
      data: name
    },
    series: [{
      name: '数量',
      type: 'bar',
      barWidth: '70%',
      data: value,
      itemStyle: {
        borderRadius: [6, 6, 0, 0],
        borderWidth: 0,
        shadowColor: 'rgba(0,0,0,0.1)',
        shadowBlur: 6,
        shadowOffsetY: 3
      },
      label: {
        show: true,
        position: 'top',
        distance: 10,
        color: '#495057',
        fontSize: 10,
        fontWeight: 600,
        formatter: '{c}'
      },
      emphasis: {
        itemStyle: {
          shadowColor: 'rgba(0,0,0,0.2)',
          shadowBlur: 8,
          shadowOffsetY: 4,
          opacity: 0.9
        }
      }
    }],
    visualMap: {
      ...option.value.visualMap,
      max: Math.max(...value) * 1.2
    }
  };
};


initChart();

</script>

<style scoped>
.chart {
  width: 100%;
  height: 90%;
  min-height: 280px;
  background: transparent;
  border-radius: 12px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.05);
  padding: 16px;
  box-sizing: border-box;
}
</style>
