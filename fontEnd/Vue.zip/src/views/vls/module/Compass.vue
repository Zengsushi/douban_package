<template>
  <v-chart class="chart" :option="option" autoresize @click="handleClick" />
</template>

<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import VChart from 'vue-echarts'
import { use } from 'echarts/core'
import { SunburstChart } from 'echarts/charts'
import { TooltipComponent } from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'

import { GetFindByTitle } from '@/views/api/index'
import router from "@/router/index"
import { useStore } from "@/pinia/index"

const store = useStore()

use([SunburstChart, TooltipComponent, CanvasRenderer])

const colors = ['#00BFFF', '#1E90FF', '#4169E1', '#5F9EA0', '#4682B4']
const bgColor = '#0F1B2A'

const itemStyle: Record<`star${number}`, { color: string }> = {
  star5: { color: colors[0] },
  star4: { color: colors[1] },
  star3: { color: colors[2] },
  star2: { color: colors[3] },
  star1: { color: colors[4] }
}

interface BookNode {
  name: string
  value?: number
  itemStyle?: any
  label?: any
  children?: BookNode[]
}

interface CountryNode {
  name: string
  children?: BookNode[]
  itemStyle?: any
}

interface ChartDataNode {
  name: string
  itemStyle: { color: string }
  children?: CountryNode[]
}

const props = defineProps<{
  data: ChartDataNode[]
}>()

processData(props.data)

function processData(dataSet: ChartDataNode[]) {
  for (let region of dataSet) {
    for (let country of region.children || []) {
      const block = country.children || []
      for (let ratingNode of block) {
        const score = Math.floor(parseFloat(ratingNode.name))
        const style = itemStyle[`star${score}` as keyof typeof itemStyle] || { color: '#888' }

        ratingNode.label = {
          color: style.color,
          downplay: { opacity: 0.5 }
        }

        if (ratingNode.children) {
          const childStyle = {
            opacity: 1,
            color: style.color
          }

          for (let book of ratingNode.children) {
            book.value = 1
            book.itemStyle = childStyle
            book.label = { color: childStyle.color }
          }
        }
      }

      country.itemStyle = {
        color: region.itemStyle.color
      }
    }
  }
}

const option = ref({
  backgroundColor: 'transparent',
  color: colors,
  series: [
    {
      type: 'sunburst',
      center: ['50%', '48%'],
      data: props.data,
      sort: (a: any, b: any) =>
        a.depth === 1 ? b.getValue() - a.getValue() : a.dataIndex - b.dataIndex,
      label: {
        rotate: 'radial',
        color: bgColor
      },
      itemStyle: {
        borderColor: bgColor,
        borderWidth: 2
      },
      levels: [
        {},
        {
          r0: 0,
          r: 40,
          label: {
            rotate: 0
          }
        },
        {
          r0: 40,
          r: 105
        },
        {
          r0: 115,
          r: 140,
          itemStyle: {
            shadowBlur: 2,
            shadowColor: colors[2],
            color: 'transparent'
          },
          label: {
            rotate: 'tangential',
            fontSize: 10,
            color: colors[1]
          }
        },
        {
          r0: 140,
          r: 145,
          itemStyle: {
            shadowBlur: 80,
            shadowColor: colors[1]
          },
          label: {
            position: 'outside',
            textShadowBlur: 5,
            textShadowColor: '#333'
          },
          downplay: {
            label: {
              opacity: 0.5
            }
          }
        }
      ]
    }
  ]
})

const handleClick = async (data: any) => {
  if (data.data.children === undefined) {
    try {
      const res = await GetFindByTitle({ title: data.data.name + " " })
      localStorage.setItem("mvId", res.data.data)
      router.push("/info")
    } catch {
      const res = await GetFindByTitle({ title: data.data.name })
      localStorage.setItem("mvId", res.data.data)
      router.push("/info")
    }
  }
}
</script>

<style scoped>
.chart {
  /* padding-top: 10%; */
  width: 100%;
  height: 100%;
  min-height: 580px;
}
</style>