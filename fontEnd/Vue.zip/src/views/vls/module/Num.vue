<template>
  <div class="rolling-number-container">
    <div class="number-title">{{ props.name }}</div>
    <div class="rolling-number-display">
      <div 
        v-for="(digit, index) in displayDigits" 
        :key="`digit-${index}`" 
        class="digit-column"
        :style="columnStyle(index)"
      >
        <div 
          class="digit-scroll" 
          :style="scrollStyle(digit)"
        >
          <div 
            v-for="n in digitOptions" 
            :key="`digit-${n}`" 
            class="digit"
          >
            {{ n }}
          </div>
          <!-- 额外添加0-9数字循环以实现无缝滚动 -->
          <div 
            v-for="n in digitOptions" 
            :key="`digit-copy-${n}`" 
            class="digit"
          >
            {{ n }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, watch, computed, onMounted } from 'vue';
import type { Props , Digit } from "@/pojo/index"

const props = withDefaults(defineProps<Props>(), {
  name: '',
  number: '',
  duration: 1000,
  digitHeight: 70, // 字体高度
  delayStep: 50 
});



const digitOptions = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
const displayDigits = ref<Digit[]>([]);

// 获取实际显示的数字值（兼容新旧属性）
const displayValue = computed(() => {
  return props.number || '0';
});

// 初始化数字
const initializeDigits = (value: string) => {
  const safeValue = value.toString().replace(/\D/g, '') || '0';
  displayDigits.value = safeValue.split('').map(num => ({
    value: num,
    position: parseInt(num, 10)
  }));
};

// 更新数字并触发滚动动画
const updateDigits = (newValue: string) => {
  const safeValue = newValue.toString().replace(/\D/g, '') || '0';
  const newDigits = safeValue.split('');
  
  // 如果长度变化，直接重新初始化
  if (newDigits.length !== displayDigits.value.length) {
    initializeDigits(safeValue);
    return;
  }

  // 更新数字位置
  displayDigits.value = displayDigits.value.map((digit, index) => {
    const newValue = newDigits[index];
    const currentPos = parseInt(digit.value, 10);
    const targetPos = parseInt(newValue, 10);
    
    // 计算滚动距离(考虑循环滚动)
    let distance = targetPos - currentPos;
    if (distance < 0) distance += 10; // 向上滚动
    
    return {
      value: newValue,
      position: digit.position + distance
    };
  });
};

// 列样式计算
const columnStyle = (index: number) => ({
  '--digit-height': `${props.digitHeight}px`,
  '--animation-duration': `${props.duration}ms`,
  '--delay': `${index * props.delayStep}ms`
});

// 滚动样式计算
const scrollStyle = (digit: Digit) => ({
  transform: `translateY(${-digit.position * props.digitHeight}px)`
});

// 初始化
onMounted(() => {
  initializeDigits(displayValue.value);
});

// 监听数字变化
watch(displayValue, (newVal) => {
  updateDigits(newVal);
}, { immediate: true });
</script>

<style scoped lang="scss">
/* 样式保持不变 */
.rolling-number-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin: 10px;
}

.number-title {
  font-size: 16px;
  color: #30cfd0;
  margin-bottom: 8px;
  text-shadow: 0 0 5px rgba(48, 207, 208, 0.5);
}

.rolling-number-display {
  display: flex;
  justify-content: center;
  align-items: center;
  height: var(--digit-height);
  overflow: hidden;
}

.digit-column {
  position: relative;
  width: 50px;
  height: var(--digit-height);
  overflow: hidden;
  margin: 0 4px;
}

.digit-scroll {
  position: absolute;
  width: 100%;
  transition: transform var(--animation-duration) cubic-bezier(0.25, 1, 0.5, 1);
  transition-delay: var(--delay);
}

.digit {
  height: var(--digit-height);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 30px;
  font-weight: 700;
  color: #fff;
  background: linear-gradient(135deg, #1c2b50, #2a3c6b);
  border-radius: 4px;
  box-shadow: 
    0 2px 6px rgba(0, 0, 0, 0.3),
    inset 0 1px 1px rgba(255, 255, 255, 0.1);
}

/* 响应式调整 */
@media (max-width: 768px) {
  .digit {
    font-size: 20px;
  }
  
  .digit-column {
    width: 24px;
  }
}
</style>