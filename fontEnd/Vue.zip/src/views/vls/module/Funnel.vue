<template>
    <div class="chart-container">
      <v-chart v-if="chartData.length > 0" class="chart" :option="option" autoresize />
      <!-- <div v-else class="loading">
        <div class="loading-spinner"></div>
        <div>数据加载中...</div>  
      </div> -->
    </div>
  </template>
  
  <script lang="ts" setup>
  import { computed } from "vue"
  import { use } from "echarts/core"
  import VChart from "vue-echarts"
  import { FunnelChart } from "echarts/charts"
  import {
    TitleComponent,
    TooltipComponent,
    ToolboxComponent,
    LegendComponent,
    GridComponent
  } from "echarts/components"
  import { CanvasRenderer } from "echarts/renderers"
  
  // 注册必要的组件
  use([
    TitleComponent,
    TooltipComponent,
    ToolboxComponent,
    LegendComponent,
    GridComponent,
    FunnelChart,
    CanvasRenderer
  ])
  
  // 蓝色系渐变颜色生成
  const generateBlueGradient = (index: number, total: number) => {
    const baseHue = 200 // 基础蓝色色调
    const hueRange = 40 // 色调变化范围
    const hue = baseHue + (index * hueRange / total)
    const saturation = 80 + (index * 10 / total) // 饱和度渐变
    const lightness = 50 - (index * 15 / total) // 亮度渐变
    return `hsl(${hue}, ${saturation}%, ${lightness}%)`
  }
  
  const props = defineProps({
    data: {
      type: Array as () => Array<{ name: string; value: number }>,
      required: true,
      default: () => [],
      validator: (value: any[]) => value.every(item => item.name && item.value !== undefined)
    }
  })

  // 处理图表数据
  const chartData = computed(() => {
    if (!props.data || !Array.isArray(props.data)) return []
    
    return props.data.map((item, index) => ({
      name: item.name,
      value: item.value,
      itemStyle: {
        color: generateBlueGradient(index, props.data.length),
        borderColor: 'rgba(255, 255, 255, 0.8)',
        borderWidth: 1
      }
    }))
  })
  
  const option = computed(() => ({
    backgroundColor: 'transparent',
    title: {
      text: '评论热度TOP' + props.data.length,
      left: 'center',
      top: 15,
      textStyle: {
        color: 'rgba(100, 200, 255, 0.9)',
        fontSize: 18,
        fontWeight: 'bold',
        textShadow: '0 2px 10px rgba(0, 150, 255, 0.5)'
      }
    },
    tooltip: {
      trigger: 'item',
      backgroundColor: 'rgba(0, 20, 40, 0.9)',
      borderColor: 'rgba(0, 180, 255, 0.8)',
      borderWidth: 1,
      padding: [10, 15],
      textStyle: {
        color: '#fff',
        fontSize: 13,
        lineHeight: 22
      },
      formatter: (params: any) => {
        return `
          <div style="margin-bottom:8px;color:#64c8ff;font-weight:bold;font-size:14px">
            ${params.name}
          </div>
          <div style="margin-bottom:5px">评论热度: <span style="color:#FFD700">${params.value}</span></div>
          <div>占比: ${params.percent}%</div>
        `
      }
    },
    toolbox: {
      right: 20,
      top: 15,
      feature: {
        dataView: {
          readOnly: false,
          title: '数据视图',
          buttonColor: 'rgba(0, 150, 255, 0.8)',
          textStyle: { color: '#fff' },
          iconStyle: { color: '#fff' }
        },
        saveAsImage: {
          title: '保存图片',
          pixelRatio: 2,
          backgroundColor: 'rgba(15, 27, 42, 0.8)',
          iconStyle: { color: '#fff' }
        }
      },
      iconStyle: {
        color: 'rgba(100, 200, 255, 0.8)',
        borderColor: 'rgba(0, 180, 255, 0.5)'
      }
    },
    legend: {
      data: chartData.value.map(item => item.name),
      bottom: 10,
      itemGap: 8,
      itemWidth: 12,
      itemHeight: 12,
      textStyle: {
        color: 'rgba(180, 220, 255, 0.9)',
        fontSize: 12,
        rich: {
          a: {
            width: 12,
            height: 12,
            borderRadius: 6,
            align: 'center',
            verticalAlign: 'middle'
          },
          b: {
            padding: [0, 0, 0, 5],
            verticalAlign: 'middle'
          }
        }
      },
      formatter: (name: string) => {
        const item = chartData.value.find(item => item.name === name)
        const color = item?.itemStyle?.color || '#ccc'
        return `{a|${name}}`
      }
    },
    series: [{
      name: '评论热度',
      type: 'funnel',
      left: '15%',
      top: 70,
      bottom: 90,
      width: '70%',
      min: 0,
      max: Math.max(...chartData.value.map(item => item.value), 100),
      minSize: '15%',
      maxSize: '100%',
      sort: 'descending',
      gap: 8,
      label: {
        show: true,
        position: 'inside',
        color: '#fff',
        fontSize: 12,
        fontWeight: 'bold',
        formatter: (params: any) => `${params.name}\n${params.value}`
      },
      labelLine: {
        length: 10,
        lineStyle: {
          width: 1,
          color: 'rgba(0, 180, 255, 0.6)'
        }
      },
      itemStyle: {
        borderRadius: 6,
        borderWidth: 1,
        borderColor: 'rgba(255, 255, 255, 0.8)',
        shadowBlur: 10,
        shadowColor: 'rgba(0, 150, 255, 0.4)'
      },
      emphasis: {
        label: {
          fontSize: 14,
          color: '#FFD700'
        },
        itemStyle: {
          shadowBlur: 15,
          shadowColor: 'rgba(255, 215, 0, 0.6)',
          borderColor: '#FFD700'
        }
      },
      data: chartData.value,
      animationType: 'expansion',
      animationDuration: 1200,
      animationEasing: 'cubicOut',
      animationDelay: (idx: number) => idx * 100
    }],
    grid: {
      containLabel: true
    }
  }))

 
  
  </script>
  
  <style scoped>
  .chart-container {
    background-color: "transparent";
    width: 100%;
    height: 100%;
    /* min-height: 500px; */
    /* background: linear-gradient(145deg, rgba(10,25,45,0.95) 0%, rgba(5,15,35,0.95) 100%); */
    border-radius: 12px;
    /* box-shadow: 0 5px 25px rgba(0, 150, 255, 0.2); */
    overflow: hidden;
    transition: all 0.3s ease;
  }
  
  .chart-container:hover {
    box-shadow: 0 8px 30px rgba(0, 180, 255, 0.3);
    transform: translateY(-2px);
  }
  
  .chart {
    background-color: transparent ;
    width: 100%;
    height: 100%;
    padding: 15px;
    box-sizing: border-box;
  }
  
  .loading {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 100%;
    color: rgba(100, 200, 255, 0.8);
    font-size: 14px;
    gap: 15px;
  }
  
  .loading-spinner {
    width: 40px;
    height: 40px;
    border: 4px solid rgba(100, 200, 255, 0.2);
    border-top-color: rgba(100, 200, 255, 0.8);
    border-radius: 50%;
    animation: spin 1s linear infinite;
  }
  
  @keyframes spin {
    to { transform: rotate(360deg); }
  }
  
  @media (max-width: 768px) {
    .chart-container {
      min-height: 400px;
      border-radius: 8px;
    }
    
    .loading {
      font-size: 12px;
    }
    
    .loading-spinner {
      width: 30px;
      height: 30px;
      border-width: 3px;
    }
  }
  </style>