<template>
  <div style="display: flex;">
    <v-chart class="chart" :option="option" autoresize @click="handleChartClick" />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { getYearCnt } from '@/views/api/index'
import VChart from 'vue-echarts'
import { use } from 'echarts/core'
import { LineChart } from 'echarts/charts'
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  DataZoomComponent
} from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'

use([
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  DataZoomComponent,
  LineChart,
  CanvasRenderer
])

const option = ref({
  backgroundColor: 'transparent',
  title: {
    left: 'center',
    textStyle: {
      color: '#333',
      fontSize: 18,
      fontWeight: 'bold'
    }
  },
  tooltip: {
    trigger: 'axis',
    axisPointer: {
      type: 'shadow'
    },
    formatter: (params: any[]) => {
      let result = `<div style="font-weight:bold;margin-bottom:5px">${params[0].axisValue}年</div>`
      params.forEach((item: any) => {
        result += `
          <div style="display:flex;align-items:center;margin:3px 0">
            <span style="display:inline-block;width:10px;height:10px;background:${item.color};margin-right:5px"></span>
            ${item.seriesName}: <span style="font-weight:bold;margin-left:5px">${item.value}</span>
          </div>`
      })
      return result
    }
  },
  legend: {
    data: ['国外', '国内', '全部'],
    top: 30,
    itemWidth: 12,
    itemHeight: 12,
    textStyle: {
      fontSize: 12,
      color: '#666'
    }
  },
  grid: {
    left: '3%',
    right: '4%',
    bottom: '15%',
    top: '20%',
    containLabel: true
  },
  xAxis: {
    type: 'category',
    data: [] as string[],
    axisLine: {
      lineStyle: {
        color: '#ccc'
      }
    },
    axisLabel: {
      color: '#666'
    }
  },
  yAxis: {
    type: 'value',
    axisLine: {
      show: true,
      lineStyle: {
        color: '#ccc'
      }
    },
    axisLabel: {
      color: '#666'
    },
    splitLine: {
      lineStyle: {
        type: 'dashed',
        color: '#eaeaea'
      }
    }
  },
  dataZoom: [
    {
      type: 'inside',
      start: 0,
      end: 100
    },
    {
      start: 0,
      end: 100,
      bottom: 5,
      height: 20
    }
  ],
  series: [
    {
      name: '国外',
      type: 'line',
      smooth: true,
      symbol: 'circle',
      symbolSize: 8,
      lineStyle: {
        width: 3,
        color: '#5470C6'
      },
      itemStyle: {
        color: '#5470C6'
      },
      areaStyle: {
        color: {
          type: 'linear',
          x: 0, y: 0, x2: 0, y2: 1,
          colorStops: [
            { offset: 0, color: 'rgba(84, 112, 198, 0.5)' },
            { offset: 1, color: 'rgba(84, 112, 198, 0.1)' }
          ]
        }
      },
      data: [] as number[]
    },
    {
      name: '国内',
      type: 'line',
      smooth: true,
      symbol: 'circle',
      symbolSize: 8,
      lineStyle: {
        width: 3,
        color: '#91CC75'
      },
      itemStyle: {
        color: '#91CC75'
      },
      areaStyle: {
        color: {
          type: 'linear',
          x: 0, y: 0, x2: 0, y2: 1,
          colorStops: [
            { offset: 0, color: 'rgba(145, 204, 117, 0.5)' },
            { offset: 1, color: 'rgba(145, 204, 117, 0.1)' }
          ]
        }
      },
      data: [] as number[]
    },
    {
      name: '全部',
      type: 'line',
      smooth: true,
      symbol: 'circle',
      symbolSize: 8,
      lineStyle: {
        width: 3,
        color: '#EE6666'
      },
      itemStyle: {
        color: '#EE6666'
      },
      areaStyle: {
        color: {
          type: 'linear',
          x: 0, y: 0, x2: 0, y2: 1,
          colorStops: [
            { offset: 0, color: 'rgba(238, 102, 102, 0.5)' },
            { offset: 1, color: 'rgba(238, 102, 102, 0.1)' }
          ]
        }
      },
      data: [] as number[]
    }
  ]
})

const loading = ref(true)

const handleChartClick = (params: any) => {
  console.log('Chart clicked:', params)
}

const getOptionData = async () => {
  try {
    loading.value = true
    const res = await getYearCnt()
    if (res.data.code === 0) {
      const years: string[] = []
      const outCounts: number[] = []
      const inCounts: number[] = []
      const totalCounts: number[] = []

      res.data.data.forEach((item: any) => {
        years.push(item.year)
        outCounts.push(item.out_cnt)
        inCounts.push(item.in_cnt)
        totalCounts.push(item.in_cnt + item.out_cnt)
      })

      option.value.xAxis = {
        ...(option.value.xAxis as any),
        data: years
      }

      option.value.series[0].data = outCounts
      option.value.series[1].data = inCounts
      option.value.series[2].data = totalCounts
    }
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  getOptionData()
})
</script>

<style scoped>
.chart {
  width: 100%;
  min-height: 380px;
}
</style>
