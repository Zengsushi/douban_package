<template>
  <div class="container">
    <!-- 头部面板 -->
    <header class="app-header">
      <el-row :gutter="20" justify="space-between" align="middle">
        <el-col :span="4">
          <div class="app-logo">豆瓣电影分析系统</div>
        </el-col>
        <el-col :span="14" 
            style="text-align: center;
            color: var(--el-color-primary);"
            @click="router.push('/MovieVls')"
            ><el-icon><SwitchFilled /></el-icon></el-col>
        <el-col :span="4">
          <div class="user-info" @click="drawer = true">
              <el-icon><User /></el-icon>
              <span>{{ user?.nickName }}</span>
          </div>
          <el-drawer v-model="drawer" title="用户基本信息" :with-header="false" style="display: block;">
            
            <el-button type="primary" @click="headBnt" > 退出登录</el-button>

            <div class="user-infos">
              <el-descriptions title="用户信息" :column="1" border v-if="!isEditing">
                <el-descriptions-item label="用户名">{{ user?.name }}</el-descriptions-item>
                <el-descriptions-item label="昵称">{{ user?.nickName }}</el-descriptions-item>
                <el-descriptions-item label="邮箱">{{ user?.email }}</el-descriptions-item>
                <el-descriptions-item label="性别">{{ user?.gender }}</el-descriptions-item>
                <el-descriptions-item label="生日">{{ user?.birth }}</el-descriptions-item>
              </el-descriptions>
              <el-form v-else :model="user ?? {}" label-width="60px">
                <el-form-item label="用户名">
                  <el-input v-model="user!.name" />
                </el-form-item>
                <el-form-item label="昵称">
                  <el-input v-model="user!.nickName" />
                </el-form-item>
                <el-form-item label="邮箱">
                  <el-input v-model="user!.email" />
                </el-form-item>
                <el-form-item label="性别">
                  <el-input v-model="user!.gender" />
                </el-form-item>
                <el-form-item label="生日">
                  <el-input v-model="user!.birth" />
                </el-form-item>
              </el-form>
              <div style="margin-top: 16px; text-align: right;">
                <el-button v-if="!isEditing" type="primary" @click="isEditing = true">编辑</el-button>
                <el-button v-else type="primary" @click="submitEdit">保存</el-button>
                <el-button v-if="isEditing" @click="isEditing = false">取消</el-button>
              </div>
            </div>
          </el-drawer>
        </el-col>

      </el-row>
    </header>
    <!-- 主内容区域 -->
    <main class="app-main">
      <!-- 左侧菜单 -->
      <aside class="app-sidebar">
        <el-menu
          default-active="1-1"
          class="app-menu"
          @select="handleMenuSelect"
        >
          <el-sub-menu index="1">
            <template #title>
               <el-icon><VideoCameraFilled /></el-icon>
              <span>电影分析</span>
            </template> 
            
            <el-menu-item-group title="类型">
              <el-menu-item index="1-1">词云图(类型)</el-menu-item>
            </el-menu-item-group>
            
            <el-menu-item-group title="评分 - 评分人数">
              <el-menu-item index="2-1">柱状图(评分分布)</el-menu-item>
              <el-menu-item index="2-2">旭日图(国内外评分电影)</el-menu-item>
              <!-- <el-menu-item index="2-3">漏斗图(评分和评分人数)</el-menu-item> -->
            </el-menu-item-group>
            
            <el-menu-item-group title="年份 - 时长">
              <el-menu-item index="3-1">折线图(年份上映数量)</el-menu-item>
              <el-menu-item index="3-2">饼图(电影时长分布)</el-menu-item>
            </el-menu-item-group>
          </el-sub-menu>

          <el-sub-menu index="2">
            <template #title>
               <el-icon><Notebook /></el-icon>
              <span>书籍分析</span>
            </template> 
            
            <el-menu-item-group title="类型">
              <el-menu-item index="1-1-1">词云图(出版社)</el-menu-item>
            </el-menu-item-group>
            
            <el-menu-item-group title="评分 - 评分人数">
              <el-menu-item index="2-1-1">玫瑰图(书籍类型)</el-menu-item>
              <el-menu-item index="2-2-1">中国地图(数据出版数量)</el-menu-item>
              <!-- <el-menu-item index="2-3">漏斗图(评分和评分人数)</el-menu-item> -->
            </el-menu-item-group>
            
            <el-menu-item-group title="年份 - 时长">
              <el-menu-item index="3-1-1">折线图(书籍上映数量)</el-menu-item>
              <el-menu-item index="3-2-1">嵌套饼图(书籍页数分布 书籍价格分布)</el-menu-item>
            </el-menu-item-group>
          </el-sub-menu>
          
          <el-menu-item index="3">
            <el-icon><Setting /></el-icon>
            <span>设置</span>
          </el-menu-item>
        </el-menu>
      </aside>

      <!-- 右侧内容区 -->
      <section class="app-content">
        <div class="chart-container">
          <!-- 词云图 -->
          <template v-if="activeChart === '1-1'">
            <h3 class="chart-title">电影类型词云</h3>
            <WordClound v-if="chartData.wordCloud" :data="chartData.wordCloud" />
            <el-skeleton v-else :rows="5" animated />
          </template>

          <!-- 柱状图 -->
          <template v-if="activeChart === '2-1'">
            <h3 class="chart-title">电影评分分布</h3>
            <Bar v-if="chartData.bar" :data="chartData.bar" />
            <el-skeleton v-else :rows="5" animated />
          </template>

          <!-- 旭日图 -->
          <template v-if="activeChart === '2-2'">
            <h3 class="chart-title">国内外电影评分分布</h3>
            <Compass v-if="chartData.compass" :data="chartData.compass" 
            style=" padding-top: 20px; 
            background-color: rgb(14, 26, 59  , 0.90); 
             border-radius: 8px;"/>
            <el-skeleton v-else :rows="5" animated />
          </template>

          <!-- 漏斗图 -->
          <!-- <template v-if="activeChart === '2-3'">
            <h3 class="chart-title">评分与评分人数关系</h3>
            <Funnel v-if="chartData.funnel" :data="chartData.funnel" style="min-width: 400px; min-width: 400px;"/>
            <el-skeleton v-else :rows="5" animated />
          </template> -->

          <!-- 折线图 -->
          <template v-if="activeChart === '3-1'">
            <h3 class="chart-title">年度上映数量趋势</h3>
            <Line v-if="chartData.line" :data="chartData.line" />
            <el-skeleton v-else :rows="5" animated />
          </template>

          <!-- 饼图 -->
          <template v-if="activeChart === '3-2'">
            <div >
            <h3 class="chart-title">电影时长分布</h3>
            <Pie v-if="chartData.pie1" :data="chartData.pie1" :font-color="'black'" title="时长分布"/>
            <h3 class="chart-title">评分分布</h3>
            <Pie v-if="chartData.pie2" :data="chartData.pie2" title="评分分布" />
            <el-skeleton v-if="!chartData.pie1 || !chartData.pie2" :rows="5" animated />
            </div>
          </template>

          <template v-if="activeChart === '1-1-1'">
            <h3 class="chart-title" style="height: 100%;">书籍出版社词云</h3>
              <bookWordCloud />
          </template>
          <template v-if="activeChart === '2-1-1'">
            <h3 class="chart-title" style="height: 100%;">书籍类型玫瑰图</h3>
              <Rose />  
          </template>
          <template v-if="activeChart === '2-2-1'">
            <h3 class="chart-title" style="height: 100%;">国内书籍出版地区</h3>
              <China />  
          </template>

          <template v-if="activeChart === '3-1-1'">
            <h3 class="chart-title" style="height: 100%;">各个年份出版书籍</h3>
              <Line2 />  
          </template>

          <template v-if="activeChart === '3-2-1'">
            <h3 class="chart-title" style="height: 100%;">书籍页数 ,价格 嵌套饼图</h3>
              <Bar2 />  
          </template>
        </div>
      </section>
    </main>
  </div>
 
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from "vue";
import { User, Location, Setting } from "@element-plus/icons-vue";
import {type Users } from "@/pojo/index"
import { ElMessage } from 'element-plus'

// 图表组件
import Pie from "@/views/vls/module/Pie.vue";
import Bar from "@/views/vls/module/Bar.vue";
import WordClound from "@/views/vls/module/WordClound.vue";
import Compass from "@/views/vls/module/Compass.vue";
import Funnel from "@/views/vls/module/Funnel.vue";
import Line from "@/views/vls/module/Line.vue";

// 书籍图表
import Bar2 from "./vls/book/Bar2.vue";
import bookWordCloud from "./vls/book/bookWordCloud.vue";
import China from "./vls/book/China.vue";
import Line2 from "./vls/book/Line.vue";
import Rose from "./vls/book/Rose.vue";


// API
import {
  getCategory,
  GetTypeCnt,
  getScoreCnt,
  GetRegionCnt,
  getScore,
  getYearCnt,
  getMvScoreCntTop25,
  GetUserInfo,  
  updateUserInfo, 
} from "@/views/api/index";
import router from "@/router";
import { storeToRefs } from "pinia";

// 定义图表数据类型
interface ChartData {
  wordCloud: any | null;
  bar: any | null;
  compass: any | null;
  funnel: any | null;
  line: any | null;
  pie1: any | null;
  pie2: any | null;
}


// 定义 API 函数类型
type ApiFunction = () => Promise<{
  data: {
    code: number;
    message?: string;
    data: any;
  };
}>;

// 状态管理
const activeChart = ref<string>("1-1");
const isLoading = ref<boolean>(false);


// 用户信息
const user = ref<Users | undefined>(
  {
    name: ' ',
    nickName: ' ',
    email: ' ',
    gender: ' ',
    birth: ' '
  }
)
const drawer = ref<boolean>(false)
const isEditing =  ref<boolean>(false)

// 用户信息修改
const submitEdit = async() => {  
  const res = await updateUserInfo({
    naem : user.value?.name,
    nickName : user.value?.nickName,
    email : user.value?.email,
    gender : user.value?.gender,
    birth : user.value?.birth
  })
  console.log("运行");
  
  if (res.data.code === 0 ){
    console.log("数据修改成功");
    isEditing.value = false;
    ElMessage({
    message: '信息保存成功.',
    type: 'success',
    })
  }else {
    ElMessage({
      message: "保存失败,请重试!"
    })
  }
};

const headBnt = () => {
  localStorage.removeItem("uId")
  router.push("/")
}

// 图表数据 - 使用类型断言
const chartData = reactive<ChartData>({
  wordCloud: null,
  bar: null,
  compass: null,
  funnel: null,
  line: null,
  pie1: null,
  pie2: null
});

// 获取用户详细信息
const getUserInfo = async () => {
  console.log(localStorage.getItem("uId"));
  
  const res = await GetUserInfo(localStorage.getItem("uId"))
  if (res.data.code === 0 ){
    user.value = res.data.data 
    console.log(user.value);
  }else{
    ElMessage({
      message: "用户信息获取失败, 请刷新页面"
    })
  }
}

// 初始化数据
const initData = () => {
  (Object.keys(chartData) as Array<keyof ChartData>).forEach((key) => {
    chartData[key] = null;
  });
};

// 统一数据获取方法
const fetchChartData = async (apiFunc: ApiFunction, dataKey: keyof ChartData) => {
  try {
    isLoading.value = true;
    const res = await apiFunc();
    if (res.data.code === 0) {
      chartData[dataKey] = res.data.data;
    } else {
      console.error("数据获取失败:", res.data.message);
    }
  } catch (error) {
    console.error("API请求错误:", error);
  } finally {
    isLoading.value = false;
  }
};

// 菜单选择处理
const handleMenuSelect = (index: string) => {
  activeChart.value = index;
  initData();
  
  switch(index) {
    case '1-1':
      fetchChartData(GetTypeCnt, 'wordCloud');
      break;
    case '2-1':
      fetchChartData(getScoreCnt, 'bar');
      break;
    case '2-2':
      fetchChartData(GetRegionCnt, 'compass');
      break;
    case '2-3':
      fetchChartData(getMvScoreCntTop25, 'funnel');
      break;
    case '3-1':
      fetchChartData(getYearCnt, 'line');
      break;
    case '3-2':
      Promise.all([
        fetchChartData(getCategory, 'pie1'),
        fetchChartData(getScore, 'pie2')
      ]);
      break;
  }
};

// 初始化加载第一个图表
handleMenuSelect('1-1');
onMounted(() => {
  getUserInfo()
  if (!localStorage.getItem("uId")){
    router.push("/")
    ElMessage({
      message: "用户未登录 , 请登录"
    })
  }
})
</script>

<style scoped>

/* 基础布局 */
.container {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background-color: #f5f7fa;
}

/* 头部样式 */
.app-header {
  height: 60px;
  padding: 0 20px;
  background-color: #ffffff;
  box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);
  /* display: flex; */
  align-items: center;
  z-index: 10;
}

.app-logo {
  font-size: 18px;
  font-weight: 600;
  color: var(--el-color-primary);
}

.user-info {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 8px;
  cursor: pointer;
  transition: all 0.3s;
  padding: 8%;
  &:hover {
    color: var(--el-color-primary);
  }
} 


/* 主内容区 */
.app-main {
  display: flex;
  flex: 1;
  overflow: hidden;

}

/* 侧边栏 */
.app-sidebar {
  width: 240px;
  background-color: #ffffff;
  border-right: 1px solid #e6e6e6;
  overflow-y: auto;
}

.app-menu {
  border-right: none;
}

/* 内容区 */
.app-content {
  flex: 1;
  padding: 20px;
  overflow-y: auto;
  background-color: #f5f7fa;
    /* background-color: rgb(14, 26, 59); */
}

.chart-container {
  background-color: #ffffff;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.08);
  min-height: calc(100% - 40px);
}

.chart-title {
  margin: 0 0 20px 0;
  padding-left: 10px;
  border-left: 4px solid var(--el-color-primary);
  font-size: 16px;
  color: black;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .app-main {
    flex-direction: column;
  }
  
  .app-sidebar {
    width: 100%;
    height: auto;
    border-right: none;
    border-bottom: 1px solid #e6e6e6;
  }
  
  .app-content {
    padding: 15px;
  }
  
  .chart-container {
    padding: 15px;
  }
}

/* 动画效果 */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

.user-infos {
  margin-top: 30%;
  margin-bottom: 20px;
}
</style>